<?php
$dbPath = __DIR__ . '/application/database/db_pilkades.sqlite';
try {
    $pdo = new PDO('sqlite:' . $dbPath);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // Add vote_count column if it doesn't exist
    $pdo->exec("ALTER TABLE tps_ballots ADD COLUMN vote_count INTEGER DEFAULT 1;");
    echo "Column vote_count added successfully.\n";
} catch (PDOException $e) {
    if (strpos($e->getMessage(), 'duplicate column name') !== false) {
        echo "Column already exists.\n";
    } else {
        echo "Error: " . $e->getMessage() . "\n";
    }
}
