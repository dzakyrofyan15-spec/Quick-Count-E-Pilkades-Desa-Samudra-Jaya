<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tps_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    // Verifikasi login panitia TPS
    public function login($username, $password) {
        $officer = $this->db->get_where('tps_officers', [
            'username'  => trim($username),
            'is_active' => 1
        ])->row_array();

        if ($officer && password_verify($password, $officer['password'])) {
            return $officer;
        }
        return false;
    }

    public function get_all() {
        $this->db->order_by('tps_number', 'ASC');
        return $this->db->get('tps_officers')->result_array();
    }

    public function get_by_id($id) {
        return $this->db->get_where('tps_officers', ['id' => $id])->row_array();
    }

    public function get_by_tps_number($tps_number) {
        return $this->db->get_where('tps_officers', ['tps_number' => $tps_number])->row_array();
    }

    public function insert($data) {
        return $this->db->insert('tps_officers', $data);
    }

    public function update($id, $data) {
        $this->db->where('id', $id);
        return $this->db->update('tps_officers', $data);
    }

    public function delete($id) {
        return $this->db->delete('tps_officers', ['id' => $id]);
    }

    // Statistik DPT per TPS
    public function get_tps_dpt_stats($tps_number) {
        $total = $this->db->where('tps_number', $tps_number)->count_all_results('voters');
        $voted = $this->db->where(['tps_number' => $tps_number, 'is_voted' => 1])->count_all_results('voters');
        return [
            'total_dpt'  => $total,
            'total_voted'=> $voted,
            'remaining'  => max(0, $total - $voted),
        ];
    }

    // Cek apakah TPS sudah pernah input suara
    public function get_tps_vote_summary($tps_number) {
        $this->db->where('tps_number', $tps_number);
        return $this->db->get('votes')->result_array();
    }
}
