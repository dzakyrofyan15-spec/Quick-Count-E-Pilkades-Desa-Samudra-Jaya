<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Candidate_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function get_all() {
        $this->db->order_by('candidate_number', 'ASC');
        return $this->db->get('candidates')->result_array();
    }

    public function get_by_id($id) {
        return $this->db->get_where('candidates', array('id' => $id))->row_array();
    }

    public function get_by_number($number) {
        return $this->db->get_where('candidates', array('candidate_number' => $number))->row_array();
    }

    public function insert($data) {
        return $this->db->insert('candidates', $data);
    }

    public function update($id, $data) {
        $this->db->where('id', $id);
        return $this->db->update('candidates', $data);
    }

    public function delete($id) {
        $candidate = $this->get_by_id($id);
        if ($candidate && !empty($candidate['photo']) && !in_array($candidate['photo'], ['calon_1.svg', 'calon_2.svg', 'calon_3.svg', 'default_candidate.svg'])) {
            $filePath = FCPATH . 'uploads/candidates/' . $candidate['photo'];
            if (file_exists($filePath)) {
                @unlink($filePath);
            }
        }
        return $this->db->delete('candidates', array('id' => $id));
    }

    public function get_next_candidate_number() {
        $this->db->select_max('candidate_number');
        $query = $this->db->get('candidates')->row_array();
        return ($query['candidate_number'] ? $query['candidate_number'] + 1 : 1);
    }
}
