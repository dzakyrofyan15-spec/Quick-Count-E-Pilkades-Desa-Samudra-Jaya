<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Voter_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function get_all() {
        $this->db->order_by('id', 'DESC');
        return $this->db->get('voters')->result_array();
    }

    public function get_by_nik($nik) {
        return $this->db->get_where('voters', array('nik' => trim($nik)))->row_array();
    }

    public function get_by_id($id) {
        return $this->db->get_where('voters', array('id' => $id))->row_array();
    }

    public function insert($data) {
        return $this->db->insert('voters', $data);
    }

    public function delete($id) {
        return $this->db->delete('voters', array('id' => $id));
    }

    public function count_total() {
        return $this->db->count_all('voters');
    }

    public function count_voted() {
        $this->db->where('is_voted', 1);
        return $this->db->count_all_results('voters');
    }

    public function generate_random_voters($count = 10) {
        $firstNames = ['Agus', 'Budi', 'Cahyo', 'Dwi', 'Endang', 'Faris', 'Gita', 'Hasan', 'Iwan', 'Jajang', 'Kiki', 'Lestari', 'Mulyadi', 'Nurmala', 'Oki', 'Pratiwi', 'Rudi', 'Siti', 'Tri', 'Utami', 'Wahyu', 'Yulia', 'Zainal'];
        $lastNames = ['Santoso', 'Prabowo', 'Wibowo', 'Kusuma', 'Suryani', 'Hidayat', 'Saputra', 'Permana', 'Utomo', 'Siregar', 'Subekti', 'Astuti', 'Purnomo'];
        
        $insertedCount = 0;
        for ($i = 0; $i < $count; $i++) {
            $fn = $firstNames[array_rand($firstNames)];
            $ln = $lastNames[array_rand($lastNames)];
            $name = $fn . ' ' . $ln;
            $nik = '317' . rand(10, 99) . rand(10, 99) . rand(10, 99) . rand(100000, 999999);
            $rt = 'RT 0' . rand(1, 9) . ' / RW 0' . rand(1, 5);

            $tps = rand(1, 12);

            // Check duplicate NIK
            if (!$this->get_by_nik($nik)) {
                $this->db->insert('voters', [
                    'nik' => $nik,
                    'name' => $name,
                    'rt_rw' => $rt,
                    'tps_number' => $tps,
                    'is_voted' => 0,
                    'created_at' => date('Y-m-d H:i:s')
                ]);
                $insertedCount++;
            }
        }
        return $insertedCount;
    }
}
