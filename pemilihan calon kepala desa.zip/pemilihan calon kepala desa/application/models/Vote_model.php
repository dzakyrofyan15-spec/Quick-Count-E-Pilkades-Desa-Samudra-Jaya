<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Vote_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    /**
     * Input bulk suara oleh panitia TPS.
     */
    public function add_bulk_votes($tps_number, $votes_array, $evidence_photo, $officer_id) {
        $this->db->trans_start();

        foreach ($votes_array as $candidate_id => $vote_count) {
            $vote_count = (int)$vote_count;
            if ($vote_count > 0) {
                // 1. Insert ke tps_ballots
                $this->db->insert('tps_ballots', [
                    'candidate_id'   => $candidate_id,
                    'tps_number'     => $tps_number,
                    'evidence_photo' => $evidence_photo,
                    'inputted_by'    => $officer_id,
                    'vote_count'     => $vote_count,
                    'created_at'     => date('Y-m-d H:i:s'),
                ]);

                // 2. Update vote_count di tabel candidates
                $this->db->set('vote_count', 'vote_count + ' . $vote_count, FALSE);
                $this->db->where('id', $candidate_id);
                $this->db->update('candidates');
                
                // 3. Update is_voted di voters (hanya simulasi partisipasi, kita update sebanyak $vote_count)
                $voters = $this->db->where('tps_number', $tps_number)->where('is_voted', 0)->limit($vote_count)->get('voters')->result_array();
                foreach ($voters as $voter) {
                    $this->db->where('id', $voter['id']);
                    $this->db->update('voters', [
                        'is_voted' => 1,
                        'voted_at' => date('Y-m-d H:i:s'),
                    ]);
                }
            }
        }

        $this->db->trans_complete();
        return $this->db->trans_status();
    }

    /**
     * Hapus satu suara (jika panitia salah input)
     */
    public function delete_single_vote($ballot_id, $tps_number) {
        $this->db->trans_start();

        // Cari data ballot
        $ballot = $this->db->where('id', $ballot_id)->where('tps_number', $tps_number)->get('tps_ballots')->row_array();
        if ($ballot) {
            $this->db->where('id', $ballot_id)->delete('tps_ballots');
            
            // Kurangi vote_count candidate
            $this->db->set('vote_count', 'vote_count - ' . (int)$ballot['vote_count'], FALSE);
            $this->db->where('id', $ballot['candidate_id']);
            $this->db->update('candidates');

            $voters = $this->db->where('tps_number', $tps_number)->where('is_voted', 1)->limit((int)$ballot['vote_count'])->get('voters')->result_array();
            foreach ($voters as $voter) {
                $this->db->where('id', $voter['id']);
                $this->db->update('voters', ['is_voted' => 0, 'voted_at' => NULL]);
            }
        }

        $this->db->trans_complete();
        return $ballot; // Kembalikan ballot untuk hapus file di controller
    }

    /**
     * Hapus semua suara dari satu TPS (Reset TPS)
     */
    public function reset_tps($tps_number) {
        $this->db->trans_start();

        // Cari semua data ballot untuk TPS ini
        $ballots = $this->db->where('tps_number', $tps_number)->get('tps_ballots')->result_array();
        
        if (!empty($ballots)) {
            foreach ($ballots as $ballot) {
                // Kurangi vote_count candidate
                $this->db->set('vote_count', 'vote_count - ' . (int)$ballot['vote_count'], FALSE);
                $this->db->where('id', $ballot['candidate_id']);
                $this->db->update('candidates');
            }
            
            // Hapus dari tps_ballots
            $this->db->where('tps_number', $tps_number)->delete('tps_ballots');

            // Reset is_voted pada tabel voters untuk TPS ini
            $this->db->where('tps_number', $tps_number)->where('is_voted', 1);
            $this->db->update('voters', ['is_voted' => 0, 'voted_at' => NULL]);
        }

        $this->db->trans_complete();
        return $ballots; // Kembalikan ballots untuk hapus file foto di controller
    }

    /**
     * Ambil riwayat suara yang sudah diinput oleh satu TPS (untuk ditampilkan di panel TPS).
     */
    public function get_tps_ballots($tps_number) {
        $this->db->select('tps_ballots.*, candidates.full_name, candidates.candidate_number');
        $this->db->from('tps_ballots');
        $this->db->join('candidates', 'candidates.id = tps_ballots.candidate_id');
        $this->db->where('tps_number', $tps_number);
        $this->db->order_by('tps_ballots.created_at', 'DESC');
        return $this->db->get()->result_array();
    }

    /**
     * Statistik global untuk dashboard admin & halaman publik
     */
    public function get_stats() {
        $totalVoters = $this->db->count_all('voters');
        $totalVoted  = $this->db->where('is_voted', 1)->count_all_results('voters');
        $totalUnvoted = max(0, $totalVoters - $totalVoted);
        $percentage   = ($totalVoters > 0) ? round(($totalVoted / $totalVoters) * 100, 1) : 0;

        $this->db->order_by('candidate_number', 'ASC');
        $candidates = $this->db->get('candidates')->result_array();

        // Hitung persentase dan breakdown per TPS per calon
        $totalVotedAll = 0;
        foreach ($candidates as $c) {
            $totalVotedAll += $c['vote_count'];
        }

        foreach ($candidates as &$c) {
            $c['percentage'] = ($totalVotedAll > 0) ? round(($c['vote_count'] / $totalVotedAll) * 100, 1) : 0;

            // TPS breakdown
            $tps_breakdown = array_fill(1, 12, 0);
            $rows = $this->db
                ->select('tps_number, SUM(vote_count) as vote_count_input')
                ->where('candidate_id', $c['id'])
                ->group_by('tps_number')
                ->get('tps_ballots')->result_array();
            foreach ($rows as $row) {
                if ($row['tps_number'] >= 1 && $row['tps_number'] <= 12) {
                    $tps_breakdown[$row['tps_number']] = (int)$row['vote_count_input'];
                }
            }
            $c['tps_breakdown'] = $tps_breakdown;
        }

        return [
            'total_voters'             => $totalVoters,
            'total_voted'              => $totalVoted,
            'total_unvoted'            => $totalUnvoted,
            'participation_percentage' => $percentage,
            'total_suara_masuk'        => $totalVotedAll,
            'candidates'               => $candidates,
        ];
    }

    /**
     * Rekap suara per TPS (untuk tabel di dashboard admin)
     * Return array: [ tps_number => [ 'total' => X, 'candidates' => [...], 'sudah_input' => bool ] ]
     */
    public function get_per_tps_summary() {
        $summary = [];
        $candidates = $this->db->order_by('candidate_number', 'ASC')->get('candidates')->result_array();

        for ($tps = 1; $tps <= 12; $tps++) {
            $rows = $this->db->select('candidate_id, SUM(vote_count) as vote_count_input')
                             ->where('tps_number', $tps)
                             ->group_by('candidate_id')
                             ->get('tps_ballots')->result_array();
            $sudah_input = $this->db->where('tps_number', $tps)->count_all_results('tps_ballots') > 0;
            $total_suara = 0;
            $cand_votes  = [];

            foreach ($rows as $r) {
                $cand_votes[$r['candidate_id']] = (int)$r['vote_count_input'];
                $total_suara += (int)$r['vote_count_input'];
            }

            $cand_detail = [];
            foreach ($candidates as $c) {
                $cand_detail[] = [
                    'id'     => $c['id'],
                    'number' => $c['candidate_number'],
                    'name'   => $c['full_name'],
                    'votes'  => isset($cand_votes[$c['id']]) ? $cand_votes[$c['id']] : 0,
                ];
            }

            $total_dpt = $this->db->where('tps_number', $tps)->count_all_results('voters');

            $officer = $this->db->select('evidence_photo')->where('tps_number', $tps)->get('tps_officers')->row_array();
            $evidence_photo = $officer ? $officer['evidence_photo'] : null;

            $summary[$tps] = [
                'tps_number'     => $tps,
                'sudah_input'    => $sudah_input,
                'total_suara'    => $total_suara,
                'total_dpt'      => $total_dpt,
                'evidence_photo' => $evidence_photo,
                'candidates'     => $cand_detail,
            ];
        }

        return $summary;
    }

    /**
     * Reset semua data suara
     */
    public function reset_all() {
        $this->db->trans_start();

        $this->db->empty_table('tps_ballots');
        $this->db->update('candidates', ['vote_count' => 0]);
        $this->db->update('voters', ['is_voted' => 0, 'voted_at' => NULL]);

        $this->db->trans_complete();
        return $this->db->trans_status();
    }
}
