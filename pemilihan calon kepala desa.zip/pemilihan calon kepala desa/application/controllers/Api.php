<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Vote_model');
    }

    public function live_count() {
        header('Content-Type: application/json');
        $stats = $this->Vote_model->get_stats();
        echo json_encode(array(
            'status' => 'success',
            'timestamp' => date('Y-m-d H:i:s'),
            'data' => $stats
        ));
    }
}
