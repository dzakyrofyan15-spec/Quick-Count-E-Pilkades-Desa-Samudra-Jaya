<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Candidate_model');
        $this->load->model('Voter_model');
        $this->load->model('Vote_model');
        $this->load->model('Tps_model');
        $this->load->library('upload');
    }

    private function _check_login() {
        if (!$this->session->userdata('admin_logged_in')) {
            redirect('admin/login');
        }
    }

    public function index() {
        if ($this->session->userdata('admin_logged_in')) {
            redirect('admin/dashboard');
        } else {
            redirect('admin/login');
        }
    }

    public function login() {
        if ($this->session->userdata('admin_logged_in')) {
            redirect('admin/dashboard');
        }

        if ($this->input->method() === 'post') {
            $username = trim($this->input->post('username', TRUE));
            $password = trim($this->input->post('password', TRUE));

            $admin = $this->db->get_where('admins', array('username' => $username))->row_array();

            if ($admin && password_verify($password, $admin['password'])) {
                $this->session->set_userdata([
                    'admin_id'         => $admin['id'],
                    'admin_username'   => $admin['username'],
                    'admin_name'       => $admin['name'],
                    'admin_logged_in'  => TRUE
                ]);
                $this->session->set_flashdata('success', 'Selamat datang kembali, ' . $admin['name'] . '!');
                redirect('admin/dashboard');
            } else {
                $this->session->set_flashdata('error', 'Username atau Password Admin salah.');
                redirect('admin/login');
            }
        }

        $data['title'] = 'Login Admin Pusat - PilKaDes 2026';
        $this->load->view('layout/header', $data);
        $this->load->view('admin/login', $data);
        $this->load->view('layout/footer', $data);
    }

    public function dashboard() {
        $this->_check_login();

        $data['title']      = 'Dashboard Monitoring Pilkades';
        $data['stats']      = $this->Vote_model->get_stats();
        $data['candidates'] = $this->Candidate_model->get_all();
        $data['tps_summary']= $this->Vote_model->get_per_tps_summary();
        $data['tps_officers']= $this->Tps_model->get_all();

        // 10 TPS yang baru saja input suara
        $data['recent_inputs'] = $this->db
            ->select('b.tps_number, MAX(b.created_at) as input_at, t.name as officer_name, COUNT(b.id) as total_suara')
            ->from('tps_ballots b')
            ->join('tps_officers t', 't.tps_number = b.tps_number', 'left')
            ->group_by('b.tps_number')
            ->order_by('input_at', 'DESC')
            ->limit(12)
            ->get()->result_array();

        $this->load->view('layout/header', $data);
        $this->load->view('admin/dashboard', $data);
        $this->load->view('layout/footer', $data);
    }

    // ─── MANAJEMEN CALON KEPALA DESA ─────────────────────────────────────
    public function candidates() {
        $this->_check_login();

        $data['title']       = 'Kelola Calon Kepala Desa';
        $data['candidates']  = $this->Candidate_model->get_all();
        $data['next_number'] = $this->Candidate_model->get_next_candidate_number();

        $this->load->view('layout/header', $data);
        $this->load->view('admin/candidates', $data);
        $this->load->view('layout/footer', $data);
    }

    public function candidate_add() {
        $this->_check_login();

        if ($this->input->method() === 'post') {
            $number  = intval($this->input->post('candidate_number', TRUE));
            $name    = trim($this->input->post('full_name', TRUE));
            $vision  = trim($this->input->post('vision', TRUE));
            $mission = trim($this->input->post('mission', TRUE));
            $slogan  = trim($this->input->post('slogan', TRUE));

            if ($this->Candidate_model->get_by_number($number)) {
                $this->session->set_flashdata('error', 'Nomor urut calon ' . $number . ' sudah digunakan.');
                redirect('admin/candidates');
            }

            $photoFilename = 'default_candidate.svg';

            if (!empty($_FILES['photo']['name'])) {
                $uploadDir = FCPATH . 'uploads/candidates/';
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0777, true);
                }

                $config['upload_path']   = $uploadDir;
                $config['allowed_types'] = 'jpg|jpeg|png|webp|svg';
                $config['max_size']      = 5120;
                $config['file_name']     = 'calon_' . $number . '_' . time();

                $this->upload->initialize($config);

                if ($this->upload->do_upload('photo')) {
                    $uploadData    = $this->upload->data();
                    $photoFilename = $uploadData['file_name'];
                } else {
                    $this->session->set_flashdata('error', 'Upload foto gagal: ' . $this->upload->display_errors('', ''));
                    redirect('admin/candidates');
                }
            }

            $this->Candidate_model->insert([
                'candidate_number' => $number,
                'full_name'        => $name,
                'photo'            => $photoFilename,
                'vision'           => $vision,
                'mission'          => $mission,
                'slogan'           => $slogan,
                'vote_count'       => 0,
                'created_at'       => date('Y-m-d H:i:s')
            ]);

            $this->session->set_flashdata('success', 'Calon Kepala Desa No. ' . $number . ' (' . $name . ') berhasil ditambahkan.');
            redirect('admin/candidates');
        }
    }

    public function candidate_edit($id) {
        $this->_check_login();

        $candidate = $this->Candidate_model->get_by_id($id);
        if (!$candidate) {
            $this->session->set_flashdata('error', 'Calon tidak ditemukan.');
            redirect('admin/candidates');
        }

        if ($this->input->method() === 'post') {
            $number  = intval($this->input->post('candidate_number', TRUE));
            $name    = trim($this->input->post('full_name', TRUE));
            $vision  = trim($this->input->post('vision', TRUE));
            $mission = trim($this->input->post('mission', TRUE));
            $slogan  = trim($this->input->post('slogan', TRUE));

            $photoFilename = $candidate['photo'];

            if (!empty($_FILES['photo']['name'])) {
                $uploadDir = FCPATH . 'uploads/candidates/';
                $config['upload_path']   = $uploadDir;
                $config['allowed_types'] = 'jpg|jpeg|png|webp|svg';
                $config['max_size']      = 5120;
                $config['file_name']     = 'calon_' . $number . '_' . time();

                $this->upload->initialize($config);

                if ($this->upload->do_upload('photo')) {
                    if (!empty($candidate['photo']) && !in_array($candidate['photo'], ['calon_1.svg', 'calon_2.svg', 'calon_3.svg', 'default_candidate.svg'])) {
                        @unlink($uploadDir . $candidate['photo']);
                    }
                    $uploadData    = $this->upload->data();
                    $photoFilename = $uploadData['file_name'];
                }
            }

            $this->Candidate_model->update($id, [
                'candidate_number' => $number,
                'full_name'        => $name,
                'photo'            => $photoFilename,
                'vision'           => $vision,
                'mission'          => $mission,
                'slogan'           => $slogan
            ]);

            $this->session->set_flashdata('success', 'Data Calon No. ' . $number . ' berhasil diperbarui.');
            redirect('admin/candidates');
        }
    }

    public function candidate_delete($id) {
        $this->_check_login();

        $candidate = $this->Candidate_model->get_by_id($id);
        if ($candidate) {
            $this->Candidate_model->delete($id);
            $this->session->set_flashdata('success', 'Calon ' . $candidate['full_name'] . ' berhasil dihapus.');
        }
        redirect('admin/candidates');
    }

    // ─── MANAJEMEN PEMILIH (DPT) ─────────────────────────────────────────
    public function voters() {
        $this->_check_login();

        $data['title']        = 'Kelola DPT (Daftar Pemilih Tetap)';
        $data['voters']       = $this->Voter_model->get_all();
        $data['total_voters'] = $this->Voter_model->count_total();
        $data['total_voted']  = $this->Voter_model->count_voted();

        $this->load->view('layout/header', $data);
        $this->load->view('admin/voters', $data);
        $this->load->view('layout/footer', $data);
    }

    public function voter_add() {
        $this->_check_login();

        if ($this->input->method() === 'post') {
            $nik        = trim($this->input->post('nik', TRUE));
            $name       = trim($this->input->post('name', TRUE));
            $rt_rw      = trim($this->input->post('rt_rw', TRUE));
            $tps_number = (int) $this->input->post('tps_number', TRUE);
            if ($tps_number < 1)  $tps_number = 1;
            if ($tps_number > 12) $tps_number = 12;

            if ($this->Voter_model->get_by_nik($nik)) {
                $this->session->set_flashdata('error', 'NIK ' . $nik . ' sudah terdaftar dalam DPT.');
                redirect('admin/voters');
            }

            $this->Voter_model->insert([
                'nik'        => $nik,
                'name'       => $name,
                'rt_rw'      => $rt_rw,
                'tps_number' => $tps_number,
                'is_voted'   => 0,
                'created_at' => date('Y-m-d H:i:s')
            ]);

            $this->session->set_flashdata('success', 'Pemilih ' . $name . ' berhasil ditambahkan ke DPT TPS ' . $tps_number . '.');
            redirect('admin/voters');
        }
    }

    public function voter_generate() {
        $this->_check_login();

        $count   = intval($this->input->post('count', TRUE));
        if ($count <= 0)   $count = 10;
        if ($count > 100)  $count = 100;

        $created = $this->Voter_model->generate_random_voters($count);
        $this->session->set_flashdata('success', 'Berhasil generate ' . $created . ' data DPT baru secara acak.');
        redirect('admin/voters');
    }

    public function voter_delete($id) {
        $this->_check_login();

        $this->Voter_model->delete($id);
        $this->session->set_flashdata('success', 'Data pemilih berhasil dihapus dari DPT.');
        redirect('admin/voters');
    }

    // ─── MANAJEMEN AKUN TPS ──────────────────────────────────────────────
    public function tps_officers() {
        $this->_check_login();

        $data['title']    = 'Kelola Akun Panitia TPS';
        $data['officers'] = $this->Tps_model->get_all();

        $this->load->view('layout/header', $data);
        $this->load->view('admin/tps_officers', $data);
        $this->load->view('layout/footer', $data);
    }

    public function tps_officer_edit($id) {
        $this->_check_login();

        $officer = $this->Tps_model->get_by_id($id);
        if (!$officer) {
            $this->session->set_flashdata('error', 'Data TPS tidak ditemukan.');
            redirect('admin/tps_officers');
        }

        if ($this->input->method() === 'post') {
            $name     = trim($this->input->post('name', TRUE));
            $location = trim($this->input->post('location', TRUE));
            $password = trim($this->input->post('password', TRUE));
            $is_active= (int) $this->input->post('is_active', TRUE);

            $updateData = [
                'name'      => $name,
                'location'  => $location,
                'is_active' => $is_active,
            ];

            if (!empty($password)) {
                $updateData['password'] = password_hash($password, PASSWORD_BCRYPT);
            }

            $this->Tps_model->update($id, $updateData);
            $this->session->set_flashdata('success', 'Akun Panitia TPS ' . $officer['tps_number'] . ' berhasil diperbarui.');
            redirect('admin/tps_officers');
        }
    }

    // ─── RESET & LAPORAN ─────────────────────────────────────────────────

    public function reset_tps($tps_number) {
        $this->_check_login();

        $deleted_ballots = $this->Vote_model->reset_tps($tps_number);
        
        if (!empty($deleted_ballots)) {
            // Delete evidence photos
            $deleted_photos = [];
            foreach ($deleted_ballots as $ballot) {
                $photo = $ballot['evidence_photo'];
                if (!empty($photo) && !in_array($photo, $deleted_photos)) {
                    if (file_exists('./uploads/evidence/' . $photo)) {
                        unlink('./uploads/evidence/' . $photo);
                    }
                    $deleted_photos[] = $photo;
                }
            }
            $this->session->set_flashdata('success', 'Data suara TPS ' . $tps_number . ' berhasil dihapus. Panitia TPS dapat menginput ulang.');
        } else {
            $this->session->set_flashdata('info', 'Tidak ada data suara di TPS ' . $tps_number . ' untuk dihapus.');
        }

        redirect('admin/dashboard');
    }

    public function print_report() {
        $this->_check_login();

        $data['title']      = 'Berita Acara Perhitungan Suara Pilkades';
        $data['stats']      = $this->Vote_model->get_stats();
        $data['candidates'] = $this->Candidate_model->get_all();
        $data['tps_summary']= $this->Vote_model->get_per_tps_summary();

        $this->load->view('admin/print_report', $data);
    }

    // ─── LOGOUT ────────────────────────────────────────────────
    public function logout() {
        $this->session->unset_userdata(['admin_id', 'admin_name', 'admin_logged_in']);
        $this->session->set_flashdata('info', 'Anda telah berhasil keluar.');
        redirect('admin/login');
    }

    // ─── GALLERY BUKTI SURAT SUARA PER TPS ────────────────────
    public function tps_ballots($tps_number) {
        $this->_check_login();
        
        $data['title'] = 'Galeri Surat Suara TPS ' . $tps_number . ' - PilKaDes 2026';
        $data['tps_number'] = $tps_number;
        $data['ballots'] = $this->Vote_model->get_tps_ballots($tps_number);
        
        $this->load->view('layout/header', $data);
        $this->load->view('admin/tps_ballots', $data);
        $this->load->view('layout/footer', $data);
    }
}
