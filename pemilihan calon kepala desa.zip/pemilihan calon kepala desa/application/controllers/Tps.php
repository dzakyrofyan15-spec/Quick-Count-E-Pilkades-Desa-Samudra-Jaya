<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Controller Tps — Login dan Input Suara oleh Panitia TPS
 * Akses: /tps/login, /tps/dashboard, /tps/input, /tps/logout
 */
class Tps extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Tps_model');
        $this->load->model('Candidate_model');
        $this->load->model('Vote_model');
        $this->load->model('Voter_model');
    }

    private function _check_tps_login() {
        if (!$this->session->userdata('tps_logged_in')) {
            redirect('tps/login');
        }
    }

    public function index() {
        if ($this->session->userdata('tps_logged_in')) {
            redirect('tps/dashboard');
        } else {
            redirect('tps/login');
        }
    }

    // ─── LOGIN ────────────────────────────────────────────────
    public function login() {
        if ($this->session->userdata('tps_logged_in')) {
            redirect('tps/dashboard');
        }

        if ($this->input->method() === 'post') {
            $username = trim($this->input->post('username', TRUE));
            $password = trim($this->input->post('password', TRUE));

            $officer = $this->Tps_model->login($username, $password);

            if ($officer) {
                $this->session->set_userdata([
                    'tps_officer_id'     => $officer['id'],
                    'tps_officer_name'   => $officer['name'],
                    'tps_number'         => $officer['tps_number'],
                    'tps_location'       => $officer['location'],
                    'tps_logged_in'      => TRUE,
                ]);
                $this->session->set_flashdata('success', 'Selamat datang, ' . $officer['name'] . '! Anda login sebagai Panitia TPS ' . $officer['tps_number'] . '.');
                redirect('tps/dashboard');
            } else {
                $this->session->set_flashdata('error', 'Username atau Password TPS salah. Hubungi Admin Pusat jika lupa.');
                redirect('tps/login');
            }
        }

        $data['title'] = 'Login Panitia TPS - PilKaDes 2026';
        $this->load->view('layout/header', $data);
        $this->load->view('tps/login', $data);
        $this->load->view('layout/footer', $data);
    }

    // ─── DASHBOARD INPUT SUARA ────────────────────────────────
    public function dashboard() {
        $this->_check_tps_login();

        $tpsNumber = $this->session->userdata('tps_number');
        $officerId = $this->session->userdata('tps_officer_id');

        $data['title']        = 'Panel Input Suara TPS ' . $tpsNumber;
        $data['tps_number']   = $tpsNumber;
        $data['officer_name'] = $this->session->userdata('tps_officer_name');
        $data['location']     = $this->session->userdata('tps_location');
        $data['candidates']   = $this->Candidate_model->get_all();

        // Riwayat surat suara yang sudah diinput TPS ini
        $data['ballots'] = $this->Vote_model->get_tps_ballots($tpsNumber);
        
        $total_suara = 0;
        foreach ($data['ballots'] as $b) {
            $total_suara += (int)$b['vote_count'];
        }
        $data['total_suara_input'] = $total_suara;
        
        // Statistik DPT TPS ini
        $data['dpt_stats'] = $this->Tps_model->get_tps_dpt_stats($tpsNumber);

        $this->load->view('layout/header', $data);
        $this->load->view('tps/dashboard', $data);
        $this->load->view('layout/footer', $data);
    }

    // ─── PROSES INPUT 1 SUARA ────────────────────────────────────
    public function input_suara() {
        $this->_check_tps_login();

        if ($this->input->method() !== 'post') {
            redirect('tps/dashboard');
        }

        $tpsNumber = $this->session->userdata('tps_number');
        $officerId = $this->session->userdata('tps_officer_id');

        $votes = $this->input->post('votes', TRUE);
        
        if (empty($votes) || !is_array($votes)) {
            $this->session->set_flashdata('error', 'Masukkan jumlah suara untuk calon.');
            redirect('tps/dashboard');
        }

        $total_input_votes = 0;
        foreach ($votes as $count) {
            $total_input_votes += (int)$count;
        }

        if ($total_input_votes <= 0) {
            $this->session->set_flashdata('error', 'Total suara yang dimasukkan harus lebih dari 0.');
            redirect('tps/dashboard');
        }

        // DPT validation removed as per user request to allow dynamic input

        // Handle Evidence Photo Upload (Wajib)
        if (empty($_FILES['evidence_photo']['name'])) {
            $this->session->set_flashdata('error', 'Foto kertas suara wajib diunggah sebagai bukti.');
            redirect('tps/dashboard');
        }

        $config['upload_path']   = './uploads/evidence/';
        $config['allowed_types'] = 'gif|jpg|jpeg|png';
        $config['max_size']      = 5120; // 5MB
        $config['file_name']     = 'ballot_tps' . $tpsNumber . '_' . time() . '_' . rand(100, 999);

        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('evidence_photo')) {
            $this->session->set_flashdata('error', 'Gagal mengunggah bukti foto: ' . $this->upload->display_errors('',''));
            redirect('tps/dashboard');
            return;
        }

        $uploadData = $this->upload->data();
        $evidence_photo = $uploadData['file_name'];

        $success = $this->Vote_model->add_bulk_votes($tpsNumber, $votes, $evidence_photo, $officerId);

        if ($success) {
            $this->session->set_flashdata('success', 'Data Suara berhasil direkam.');
        } else {
            // Hapus file foto jika gagal masuk database
            if (file_exists('./uploads/evidence/' . $evidence_photo)) {
                unlink('./uploads/evidence/' . $evidence_photo);
            }
            $this->session->set_flashdata('error', 'Terjadi kesalahan saat menyimpan suara.');
        }

        redirect('tps/dashboard');
    }

    // ─── HAPUS SUARA (JIKA SALAH) ──────────────────────────────
    public function delete_ballot($ballot_id) {
        $this->_check_tps_login();
        $tpsNumber = $this->session->userdata('tps_number');

        $deleted_ballot = $this->Vote_model->delete_single_vote($ballot_id, $tpsNumber);

        if ($deleted_ballot) {
            // Hapus file foto bukti
            if (file_exists('./uploads/evidence/' . $deleted_ballot['evidence_photo'])) {
                unlink('./uploads/evidence/' . $deleted_ballot['evidence_photo']);
            }
            $this->session->set_flashdata('success', '1 Surat Suara berhasil dibatalkan/dihapus.');
        } else {
            $this->session->set_flashdata('error', 'Data suara tidak ditemukan atau Anda tidak berhak menghapusnya.');
        }

        redirect('tps/dashboard');
    }

    // ─── LOGOUT ────────────────────────────────────────────────
    public function logout() {
        $this->session->unset_userdata([
            'tps_officer_id',
            'tps_officer_name',
            'tps_number',
            'tps_location',
            'tps_logged_in',
        ]);
        $this->session->set_flashdata('info', 'Anda telah berhasil keluar dari Panel TPS.');
        redirect('tps/login');
    }
}
