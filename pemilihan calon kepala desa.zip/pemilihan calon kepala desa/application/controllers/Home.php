<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Candidate_model');
        $this->load->model('Vote_model');
        $this->load->model('Voter_model');
    }

    public function index() {
        $data['title'] = 'PilKaDeS Online - Website Pemilihan Kepala Desa';
        $data['stats'] = $this->Vote_model->get_stats();
        $data['candidates'] = $this->Candidate_model->get_all();

        $this->load->view('layout/header', $data);
        $this->load->view('home/index', $data);
        $this->load->view('layout/footer', $data);
    }
}
