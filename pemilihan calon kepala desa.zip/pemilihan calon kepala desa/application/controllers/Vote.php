<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Vote extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Voter_model');
        $this->load->model('Candidate_model');
        $this->load->model('Vote_model');
    }

    public function login() {
        // If already logged in as voter
        if ($this->session->userdata('voter_logged_in')) {
            if ($this->session->userdata('voter_is_voted') == 1) {
                redirect('vote/success');
            } else {
                redirect('vote/ballot');
            }
        }

        if ($this->input->method() === 'post') {
            $nik = trim($this->input->post('nik', TRUE));

            if (empty($nik)) {
                $this->session->set_flashdata('error', 'Masukkan NIK atau Kode Akses Pemilih Anda.');
                redirect('vote');
            }

            $voter = $this->Voter_model->get_by_nik($nik);

            if (!$voter) {
                $this->session->set_flashdata('error', 'NIK / Kode Akses Pemilih tidak terdaftar di DPT.');
                redirect('vote');
            }

            if ($voter['is_voted'] == 1) {
                $this->session->set_flashdata('warning', 'NIK ini sudah pernah memberikan suara pada ' . date('d-m-Y H:i', strtotime($voter['voted_at'])));
                // Store voter session to display receipt
                $this->session->set_userdata([
                    'voter_id' => $voter['id'],
                    'voter_nik' => $voter['nik'],
                    'voter_name' => $voter['name'],
                    'voter_is_voted' => 1,
                    'voter_logged_in' => TRUE
                ]);
                redirect('vote/success');
            }

            // Set voter session
            $this->session->set_userdata([
                'voter_id' => $voter['id'],
                'voter_nik' => $voter['nik'],
                'voter_name' => $voter['name'],
                'voter_rt_rw' => $voter['rt_rw'],
                'voter_is_voted' => 0,
                'voter_logged_in' => TRUE
            ]);

            redirect('vote/ballot');
        }

        $data['title'] = 'Login Pemilih - Bilik Suara Digital';
        $this->load->view('layout/header', $data);
        $this->load->view('vote/login', $data);
        $this->load->view('layout/footer', $data);
    }

    public function ballot() {
        if (!$this->session->userdata('voter_logged_in')) {
            redirect('vote');
        }

        // Re-check database state
        $voter = $this->Voter_model->get_by_id($this->session->userdata('voter_id'));
        if (!$voter || $voter['is_voted'] == 1) {
            $this->session->set_userdata('voter_is_voted', 1);
            redirect('vote/success');
        }

        $data['title'] = 'Bilik Suara Digital PilKades';
        $data['voter'] = $voter;
        $data['candidates'] = $this->Candidate_model->get_all();

        $this->load->view('layout/header', $data);
        $this->load->view('vote/ballot', $data);
        $this->load->view('layout/footer', $data);
    }

    public function submit() {
        if (!$this->session->userdata('voter_logged_in')) {
            redirect('vote');
        }

        $voterId = $this->session->userdata('voter_id');
        $candidateId = $this->input->post('candidate_id', TRUE);

        if (empty($candidateId)) {
            $this->session->set_flashdata('error', 'Silakan pilih salah satu Calon Kepala Desa terlebih dahulu.');
            redirect('vote/ballot');
        }

        $success = $this->Vote_model->cast_vote($voterId, $candidateId);

        if ($success) {
            $this->session->set_userdata('voter_is_voted', 1);
            $candidate = $this->Candidate_model->get_by_id($candidateId);
            $this->session->set_userdata('voted_candidate_name', $candidate ? $candidate['full_name'] : '');
            $this->session->set_userdata('voted_candidate_number', $candidate ? $candidate['candidate_number'] : '');
            $this->session->set_flashdata('success', 'Terima kasih! Suara Anda telah berhasil disalurkan dan terhitung otomatis dalam sistem.');
            redirect('vote/success');
        } else {
            $this->session->set_flashdata('error', 'Gagal menyimpan suara. Anda mungkin sudah pernah memilih atau data calon tidak valid.');
            redirect('vote/ballot');
        }
    }

    public function success() {
        if (!$this->session->userdata('voter_logged_in')) {
            redirect('vote');
        }

        $data['title'] = 'Bukti Memilih - PilKades Online';
        $data['voter_name'] = $this->session->userdata('voter_name');
        $data['voter_nik'] = $this->session->userdata('voter_nik');
        $data['candidate_name'] = $this->session->userdata('voted_candidate_name');
        $data['candidate_number'] = $this->session->userdata('voted_candidate_number');

        $this->load->view('layout/header', $data);
        $this->load->view('vote/success', $data);
        $this->load->view('layout/footer', $data);
    }

    public function logout() {
        $this->session->unset_userdata(['voter_id', 'voter_nik', 'voter_name', 'voter_rt_rw', 'voter_is_voted', 'voter_logged_in', 'voted_candidate_name', 'voted_candidate_number']);
        $this->session->set_flashdata('info', 'Anda telah keluar dari bilik suara.');
        redirect('vote');
    }
}
