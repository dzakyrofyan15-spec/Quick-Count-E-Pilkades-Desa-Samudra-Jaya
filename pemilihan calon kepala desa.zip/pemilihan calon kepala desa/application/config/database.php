<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$active_group = 'default';
$query_builder = TRUE;

$db_file = APPPATH . 'database/db_pilkades.sqlite';

// Auto setup SQLite if missing
if (!file_exists($db_file)) {
    @include_once(APPPATH . 'database/setup.php');
}

$db['default'] = array(
	'dsn'	=> 'sqlite:' . $db_file,
	'hostname' => '',
	'username' => '',
	'password' => '',
	'database' => $db_file,
	'dbdriver' => 'pdo',
	'dbprefix' => '',
	'pconnect' => FALSE,
	'db_debug' => (ENVIRONMENT !== 'production'),
	'cache_on' => FALSE,
	'cachedir' => '',
	'char_set' => 'utf8',
	'dbcollat' => 'utf8_general_ci',
	'swap_pre' => '',
	'encrypt' => FALSE,
	'compress' => FALSE,
	'stricton' => FALSE,
	'failover' => array(),
	'save_queries' => TRUE
);
