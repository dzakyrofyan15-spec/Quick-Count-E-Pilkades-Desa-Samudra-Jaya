<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/userguide3/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'home';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

// ─── Routes TPS (Panitia TPS) ─────────────────────────────────────────
$route['tps'] = 'tps/index';
$route['tps/login'] = 'tps/login';
$route['tps/dashboard'] = 'tps/dashboard';
$route['tps/input_suara'] = 'tps/input_suara';
$route['tps/logout'] = 'tps/logout';

// ─── Routes Admin Pusat ────────────────────────────────────────────────
$route['admin'] = 'admin/index';
$route['admin/login'] = 'admin/login';
$route['admin/dashboard'] = 'admin/dashboard';
$route['admin/candidates'] = 'admin/candidates';
$route['admin/candidates/add'] = 'admin/candidate_add';
$route['admin/candidates/edit/(:num)'] = 'admin/candidate_edit/$1';
$route['admin/candidates/delete/(:num)'] = 'admin/candidate_delete/$1';
$route['admin/voters'] = 'admin/voters';
$route['admin/voters/add'] = 'admin/voter_add';
$route['admin/voters/generate'] = 'admin/voter_generate';
$route['admin/voters/delete/(:num)'] = 'admin/voter_delete/$1';
$route['admin/tps_officers'] = 'admin/tps_officers';
$route['admin/tps_officers/edit/(:num)'] = 'admin/tps_officer_edit/$1';
$route['admin/reset_votes'] = 'admin/reset_votes';
$route['admin/print_report'] = 'admin/print_report';
$route['admin/logout'] = 'admin/logout';

// ─── API ──────────────────────────────────────────────────────────────
$route['api/live_count'] = 'api/live_count';
