<!-- Admin Top Navigation Subbar -->
<div class="bg-slate-900 text-white border-b border-slate-800 py-3 px-4 sm:px-6 lg:px-8">
    <div class="max-w-7xl mx-auto flex flex-wrap justify-between items-center gap-4">
        <div class="flex items-center gap-3">
            <span class="bg-amber-500/20 text-amber-400 border border-amber-500/30 px-3 py-1 rounded-lg text-xs font-bold uppercase tracking-wider">
                <i class="fa-solid fa-user-shield mr-1"></i> Mode Admin Panitia
            </span>
        </div>
        <div class="flex flex-wrap items-center gap-2">
            <a href="<?= base_url('admin/dashboard') ?>" class="px-3 py-1.5 rounded-lg text-xs font-bold text-slate-300 hover:text-white hover:bg-slate-800 transition-colors">
                <i class="fa-solid fa-gauge mr-1"></i> Dashboard
            </a>
            <a href="<?= base_url('admin/candidates') ?>" class="px-3 py-1.5 rounded-lg text-xs font-bold bg-amber-600 text-white">
                <i class="fa-solid fa-users-gear mr-1"></i> Kelola Calon & Foto
            </a>
            <a href="<?= base_url('admin/tps_officers') ?>" class="px-3 py-1.5 rounded-lg text-xs font-bold text-slate-300 hover:text-white hover:bg-slate-800 transition-colors">
                <i class="fa-solid fa-users-viewfinder mr-1"></i> Kelola TPS
            </a>
            <a href="<?= base_url('admin/logout') ?>" class="px-3 py-1.5 rounded-lg text-xs font-bold bg-rose-900/60 hover:bg-rose-800 text-rose-200 border border-rose-800/50 transition-colors">
                <i class="fa-solid fa-right-from-bracket"></i> Keluar
            </a>
        </div>
    </div>
</div>

<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
    
    <!-- Title & Add Button -->
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
            <h1 class="text-3xl font-black text-slate-900">Manajemen Calon Kepala Desa</h1>
            <p class="text-sm text-slate-500 mt-1">Upload foto calon kepala desa, kelola nomor urut, nama, serta visi dan misi.</p>
        </div>

        <button type="button" onclick="openAddModal()" class="inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs px-5 py-3 rounded-xl shadow-lg shadow-emerald-600/30 transition-all">
            <i class="fa-solid fa-user-plus text-sm"></i> Tambah / Upload Calon Baru
        </button>
    </div>

    <!-- Candidate Cards Table / Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <?php foreach ($candidates as $cand): ?>
            <div class="bg-white rounded-3xl shadow-md border border-slate-200 overflow-hidden flex flex-col justify-between hover:shadow-xl transition-all">
                
                <!-- Candidate Header Banner -->
                <div class="bg-slate-900 text-white p-4 flex justify-between items-center border-b-4 border-amber-500">
                    <span class="text-xs font-extrabold text-amber-400 uppercase tracking-widest">NOMOR URUT</span>
                    <span class="text-2xl font-black text-white bg-slate-800 w-10 h-10 rounded-full flex items-center justify-center border border-slate-700">
                        0<?= $cand['candidate_number'] ?>
                    </span>
                </div>

                <!-- Photo & Basic Info -->
                <div class="p-6 text-center space-y-4">
                    <div class="w-44 h-52 mx-auto overflow-hidden rounded-2xl border-4 border-slate-100 shadow-md bg-slate-50 flex items-center justify-center">
                        <img src="<?= base_url('uploads/candidates/' . $cand['photo']) ?>" alt="<?= htmlspecialchars($cand['full_name']) ?>" class="w-full h-full object-cover" onerror="this.src='<?= base_url('uploads/candidates/default_candidate.svg') ?>'">
                    </div>

                    <div>
                        <h3 class="text-lg font-extrabold text-slate-900"><?= htmlspecialchars($cand['full_name']) ?></h3>
                        <?php if (!empty($cand['slogan'])): ?>
                            <p class="text-xs font-semibold text-emerald-600 italic mt-1">"<?= htmlspecialchars($cand['slogan']) ?>"</p>
                        <?php endif; ?>
                    </div>

                    <!-- Vision & Mission Preview -->
                    <div class="text-left space-y-2 text-xs bg-slate-50 p-4 rounded-xl border border-slate-100">
                        <div>
                            <strong class="text-slate-900 uppercase tracking-wider block font-bold">Visi:</strong>
                            <p class="text-slate-600 mt-0.5 line-clamp-2"><?= htmlspecialchars($cand['vision']) ?></p>
                        </div>
                        <div>
                            <strong class="text-slate-900 uppercase tracking-wider block font-bold">Misi:</strong>
                            <p class="text-slate-600 mt-0.5 line-clamp-3 whitespace-pre-line"><?= htmlspecialchars($cand['mission']) ?></p>
                        </div>
                    </div>
                </div>

                <!-- Footer Actions -->
                <div class="p-4 bg-slate-50 border-t border-slate-100 flex gap-2">
                    <button type="button" onclick="openEditModal(<?= htmlspecialchars(json_encode($cand)) ?>)" class="flex-1 py-2.5 px-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs transition-colors flex items-center justify-center gap-1.5">
                        <i class="fa-solid fa-pen-to-square"></i> Edit Data
                    </button>
                    <button type="button" onclick="confirmDeleteCandidate(<?= $cand['id'] ?>, '<?= addslashes(htmlspecialchars($cand['full_name'])) ?>')" class="py-2.5 px-3 rounded-xl bg-rose-100 hover:bg-rose-200 text-rose-700 font-bold text-xs transition-colors">
                        <i class="fa-solid fa-trash"></i>
                    </button>
                </div>

            </div>
        <?php endforeach; ?>
    </div>

</div>

<!-- Modal Form Tambah / Upload Calon -->
<div id="modal-add-candidate" class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 hidden">
    <div class="bg-white rounded-3xl shadow-2xl max-w-xl w-full p-6 sm:p-8 max-h-[90vh] overflow-y-auto">
        <div class="flex justify-between items-center pb-4 border-b border-slate-100 mb-4">
            <h3 class="text-xl font-extrabold text-slate-900">Tambah & Upload Foto Calon Kepala Desa</h3>
            <button onclick="closeAddModal()" class="text-slate-400 hover:text-slate-600 text-xl font-bold">&times;</button>
        </div>

        <form action="<?= base_url('admin/candidates/add') ?>" method="POST" enctype="multipart/form-data" class="space-y-4">
            <div class="grid grid-cols-3 gap-4">
                <div>
                    <label class="block text-xs font-bold uppercase text-slate-700 mb-1">No. Urut</label>
                    <input type="number" name="candidate_number" value="<?= $next_number ?>" required class="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 text-center">
                </div>
                <div class="col-span-2">
                    <label class="block text-xs font-bold uppercase text-slate-700 mb-1">Nama Lengkap & Gelar</label>
                    <input type="text" name="full_name" required placeholder="Contoh: H. Ahmad Subarkah, S.IP." class="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-900">
                </div>
            </div>

            <!-- Upload Photo Input -->
            <div>
                <label class="block text-xs font-bold uppercase text-slate-700 mb-1">Upload Foto Calon (JPG, PNG, WEBP, SVG max 5MB)</label>
                <input type="file" name="photo" accept="image/*" onchange="previewImage(this, 'add-preview')" class="block w-full text-xs text-slate-500 file:mr-4 file:py-2.5 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-emerald-50 file:text-emerald-700 hover:file:bg-emerald-100">
                <!-- Preview -->
                <div class="mt-2 text-center">
                    <img id="add-preview" class="w-24 h-28 object-cover rounded-xl border border-slate-200 mx-auto hidden" alt="Pratinjau Foto">
                </div>
            </div>

            <div>
                <label class="block text-xs font-bold uppercase text-slate-700 mb-1">Slogan / Tagline Kampanye</label>
                <input type="text" name="slogan" placeholder="Contoh: Maju Bersama, Sejahtera Untuk Semua" class="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900">
            </div>

            <div>
                <label class="block text-xs font-bold uppercase text-slate-700 mb-1">Visi Utama</label>
                <textarea name="vision" rows="2" required placeholder="Tuliskan visi calon..." class="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900"></textarea>
            </div>

            <div>
                <label class="block text-xs font-bold uppercase text-slate-700 mb-1">Misi Program Kerja</label>
                <textarea name="mission" rows="3" required placeholder="Tuliskan poin-poin misi..." class="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900"></textarea>
            </div>

            <div class="pt-4 flex justify-end gap-3 border-t border-slate-100">
                <button type="button" onclick="closeAddModal()" class="px-5 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50">Batal</button>
                <button type="submit" class="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md">Simpan & Upload Calon</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Form Edit Calon -->
<div id="modal-edit-candidate" class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 hidden">
    <div class="bg-white rounded-3xl shadow-2xl max-w-xl w-full p-6 sm:p-8 max-h-[90vh] overflow-y-auto">
        <div class="flex justify-between items-center pb-4 border-b border-slate-100 mb-4">
            <h3 class="text-xl font-extrabold text-slate-900">Edit Data Calon Kepala Desa</h3>
            <button onclick="closeEditModal()" class="text-slate-400 hover:text-slate-600 text-xl font-bold">&times;</button>
        </div>

        <form id="edit-form" action="" method="POST" enctype="multipart/form-data" class="space-y-4">
            <div class="grid grid-cols-3 gap-4">
                <div>
                    <label class="block text-xs font-bold uppercase text-slate-700 mb-1">No. Urut</label>
                    <input type="number" id="edit-number" name="candidate_number" required class="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 text-center">
                </div>
                <div class="col-span-2">
                    <label class="block text-xs font-bold uppercase text-slate-700 mb-1">Nama Lengkap & Gelar</label>
                    <input type="text" id="edit-name" name="full_name" required class="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-900">
                </div>
            </div>

            <div>
                <label class="block text-xs font-bold uppercase text-slate-700 mb-1">Ganti Foto Calon (Kosongkan jika tidak diganti)</label>
                <input type="file" name="photo" accept="image/*" onchange="previewImage(this, 'edit-preview')" class="block w-full text-xs text-slate-500 file:mr-4 file:py-2.5 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-amber-50 file:text-amber-700 hover:file:bg-amber-100">
                <div class="mt-2 text-center">
                    <img id="edit-preview" class="w-24 h-28 object-cover rounded-xl border border-slate-200 mx-auto" alt="Pratinjau Foto">
                </div>
            </div>

            <div>
                <label class="block text-xs font-bold uppercase text-slate-700 mb-1">Slogan / Tagline</label>
                <input type="text" id="edit-slogan" name="slogan" class="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900">
            </div>

            <div>
                <label class="block text-xs font-bold uppercase text-slate-700 mb-1">Visi Utama</label>
                <textarea id="edit-vision" name="vision" rows="2" required class="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900"></textarea>
            </div>

            <div>
                <label class="block text-xs font-bold uppercase text-slate-700 mb-1">Misi Program Kerja</label>
                <textarea id="edit-mission" name="mission" rows="3" required class="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900"></textarea>
            </div>

            <div class="pt-4 flex justify-end gap-3 border-t border-slate-100">
                <button type="button" onclick="closeEditModal()" class="px-5 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50">Batal</button>
                <button type="submit" class="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs shadow-md">Update Data Calon</button>
            </div>
        </form>
    </div>
</div>

<script>
    function openAddModal() {
        document.getElementById('modal-add-candidate').classList.remove('hidden');
    }

    function closeAddModal() {
        document.getElementById('modal-add-candidate').classList.add('hidden');
    }

    function openEditModal(candidate) {
        document.getElementById('edit-form').action = '<?= base_url('admin/candidates/edit/') ?>' + candidate.id;
        document.getElementById('edit-number').value = candidate.candidate_number;
        document.getElementById('edit-name').value = candidate.full_name;
        document.getElementById('edit-slogan').value = candidate.slogan || '';
        document.getElementById('edit-vision').value = candidate.vision || '';
        document.getElementById('edit-mission').value = candidate.mission || '';
        
        const preview = document.getElementById('edit-preview');
        preview.src = '<?= base_url('uploads/candidates/') ?>' + candidate.photo;
        preview.classList.remove('hidden');

        document.getElementById('modal-edit-candidate').classList.remove('hidden');
    }

    function closeEditModal() {
        document.getElementById('modal-edit-candidate').classList.add('hidden');
    }

    function previewImage(input, previewId) {
        const preview = document.getElementById(previewId);
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                preview.src = e.target.result;
                preview.classList.remove('hidden');
            }
            reader.readAsDataURL(input.files[0]);
        }
    }

    function confirmDeleteCandidate(id, name) {
        Swal.fire({
            title: 'Hapus Calon Kepala Desa?',
            text: 'Apakah Anda yakin ingin menghapus data calon: ' + name + '?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#e11d48',
            cancelButtonColor: '#64748b',
            confirmButtonText: 'Ya, Hapus!',
            cancelButtonText: 'Batal',
            customClass: { popup: 'rounded-3xl' }
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = '<?= base_url('admin/candidates/delete/') ?>' + id;
            }
        });
    }
</script>
