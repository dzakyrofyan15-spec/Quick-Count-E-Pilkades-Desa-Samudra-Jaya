<!-- Admin Top Navigation Subbar -->
<div class="bg-slate-900 text-white border-b border-slate-800 py-3 px-4 sm:px-6 lg:px-8">
    <div class="max-w-7xl mx-auto flex flex-wrap justify-between items-center gap-4">
        <div class="flex items-center gap-3">
            <span class="bg-amber-500/20 text-amber-400 border border-amber-500/30 px-3 py-1 rounded-lg text-xs font-bold uppercase tracking-wider">
                <i class="fa-solid fa-user-shield mr-1"></i> Mode Admin Panitia
            </span>
        </div>
        <div class="flex flex-wrap items-center gap-2">
            <a href="<?= base_url('admin/dashboard') ?>" class="px-3 py-1.5 rounded-lg text-xs font-bold text-slate-300 hover:text-white hover:bg-slate-800 transition-colors">
                <i class="fa-solid fa-gauge mr-1"></i> Dashboard
            </a>
            <a href="<?= base_url('admin/candidates') ?>" class="px-3 py-1.5 rounded-lg text-xs font-bold text-slate-300 hover:text-white hover:bg-slate-800 transition-colors">
                <i class="fa-solid fa-users-gear mr-1"></i> Kelola Calon & Foto
            </a>
            <a href="<?= base_url('admin/tps_officers') ?>" class="px-3 py-1.5 rounded-lg text-xs font-bold bg-amber-600 text-white">
                <i class="fa-solid fa-users-viewfinder mr-1"></i> Kelola TPS
            </a>
            <a href="<?= base_url('admin/logout') ?>" class="px-3 py-1.5 rounded-lg text-xs font-bold bg-rose-900/60 hover:bg-rose-800 text-rose-200 border border-rose-800/50 transition-colors">
                <i class="fa-solid fa-right-from-bracket"></i> Keluar
            </a>
        </div>
    </div>
</div>

<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 class="text-2xl font-black text-slate-900">Manajemen Akun Panitia TPS</h1>
            <p class="text-sm text-slate-500">Kelola informasi dan hak akses login panitia per TPS.</p>
        </div>
    </div>

    <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <table class="w-full text-left text-sm">
            <thead class="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase font-bold text-xs">
                <tr>
                    <th class="px-6 py-4">TPS</th>
                    <th class="px-6 py-4">Username</th>
                    <th class="px-6 py-4">Nama Petugas</th>
                    <th class="px-6 py-4">Lokasi</th>
                    <th class="px-6 py-4 text-center">Status</th>
                    <th class="px-6 py-4 text-right">Aksi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
                <?php foreach ($officers as $off): ?>
                    <tr class="hover:bg-slate-50">
                        <td class="px-6 py-4 font-black text-slate-900">TPS <?= $off['tps_number'] ?></td>
                        <td class="px-6 py-4 font-mono font-medium text-slate-600"><?= htmlspecialchars($off['username']) ?></td>
                        <td class="px-6 py-4 font-bold text-slate-800"><?= htmlspecialchars($off['name']) ?></td>
                        <td class="px-6 py-4 text-slate-600 text-xs"><?= htmlspecialchars($off['location']) ?></td>
                        <td class="px-6 py-4 text-center">
                            <?php if ($off['is_active']): ?>
                                <span class="bg-emerald-100 text-emerald-700 px-2.5 py-1 rounded-md text-[10px] font-bold uppercase"><i class="fa-solid fa-check mr-1"></i> Aktif</span>
                            <?php else: ?>
                                <span class="bg-rose-100 text-rose-700 px-2.5 py-1 rounded-md text-[10px] font-bold uppercase"><i class="fa-solid fa-xmark mr-1"></i> Nonaktif</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 text-right">
                            <button type="button" onclick="editTps(<?= htmlspecialchars(json_encode($off)) ?>)" class="text-blue-600 hover:text-blue-800 text-xs font-bold bg-blue-50 hover:bg-blue-100 px-3 py-1.5 rounded-lg transition-colors">
                                Edit Akun
                            </button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Edit TPS -->
<div id="editModal" class="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 hidden flex items-center justify-center p-4">
    <div class="bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden">
        <div class="bg-slate-50 px-6 py-4 border-b border-slate-100 flex justify-between items-center">
            <h3 class="font-extrabold text-lg text-slate-900">Edit Akun TPS <span id="edit_tps_number_display"></span></h3>
            <button type="button" onclick="closeEditModal()" class="text-slate-400 hover:text-slate-600">
                <i class="fa-solid fa-xmark text-xl"></i>
            </button>
        </div>
        <form id="editForm" method="POST" action="">
            <div class="p-6 space-y-4">
                
                <div>
                    <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Username (Tidak bisa diubah)</label>
                    <input type="text" id="edit_username" readonly class="w-full px-4 py-2.5 bg-slate-100 border border-slate-200 rounded-xl text-slate-500 font-mono text-sm cursor-not-allowed">
                </div>
                
                <div>
                    <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Nama Petugas</label>
                    <input type="text" id="edit_name" name="name" required class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500">
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Lokasi TPS</label>
                    <input type="text" id="edit_location" name="location" class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500">
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Password Baru (Opsional)</label>
                    <input type="password" id="edit_password" name="password" placeholder="Kosongkan jika tidak ingin mengubah password" class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 placeholder-slate-400">
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Status Akun</label>
                    <select id="edit_is_active" name="is_active" class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500">
                        <option value="1">Aktif (Bisa Login)</option>
                        <option value="0">Nonaktif (Tidak Bisa Login)</option>
                    </select>
                </div>
            </div>
            
            <div class="bg-slate-50 px-6 py-4 border-t border-slate-100 flex justify-end gap-3">
                <button type="button" onclick="closeEditModal()" class="px-5 py-2 rounded-xl text-sm font-bold text-slate-600 hover:bg-slate-200 transition-colors">Batal</button>
                <button type="submit" class="px-5 py-2 rounded-xl text-sm font-bold text-white bg-emerald-600 hover:bg-emerald-500 shadow-md transition-colors">Simpan Perubahan</button>
            </div>
        </form>
    </div>
</div>

<script>
    function editTps(officer) {
        document.getElementById('edit_tps_number_display').textContent = officer.tps_number;
        document.getElementById('edit_username').value = officer.username;
        document.getElementById('edit_name').value = officer.name;
        document.getElementById('edit_location').value = officer.location;
        document.getElementById('edit_password').value = '';
        document.getElementById('edit_is_active').value = officer.is_active;
        
        document.getElementById('editForm').action = '<?= base_url("admin/tps_officers/edit/") ?>' + officer.id;
        document.getElementById('editModal').classList.remove('hidden');
    }

    function closeEditModal() {
        document.getElementById('editModal').classList.add('hidden');
    }
</script>
