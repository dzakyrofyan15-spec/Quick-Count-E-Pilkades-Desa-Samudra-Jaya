<!-- Admin Top Navigation Subbar -->
<div class="bg-slate-900 text-white border-b border-slate-800 py-3 px-4 sm:px-6 lg:px-8">
    <div class="max-w-7xl mx-auto flex flex-wrap justify-between items-center gap-4">
        <div class="flex items-center gap-3">
            <span class="bg-amber-500/20 text-amber-400 border border-amber-500/30 px-3 py-1 rounded-lg text-xs font-bold uppercase tracking-wider">
                <i class="fa-solid fa-user-shield mr-1"></i> Mode Admin Panitia
            </span>
        </div>
        <div class="flex flex-wrap items-center gap-2">
            <a href="<?= base_url('admin/dashboard') ?>" class="px-3 py-1.5 rounded-lg text-xs font-bold text-slate-300 hover:text-white hover:bg-slate-800 transition-colors">
                <i class="fa-solid fa-gauge mr-1"></i> Dashboard
            </a>
            <a href="<?= base_url('admin/candidates') ?>" class="px-3 py-1.5 rounded-lg text-xs font-bold text-slate-300 hover:text-white hover:bg-slate-800 transition-colors">
                <i class="fa-solid fa-users-gear mr-1"></i> Kelola Calon & Foto
            </a>
            <a href="<?= base_url('admin/tps_officers') ?>" class="px-3 py-1.5 rounded-lg text-xs font-bold text-slate-300 hover:text-white hover:bg-slate-800 transition-colors">
                <i class="fa-solid fa-users-viewfinder mr-1"></i> Kelola TPS
            </a>
            <a href="<?= base_url('admin/logout') ?>" class="px-3 py-1.5 rounded-lg text-xs font-bold bg-rose-900/60 hover:bg-rose-800 text-rose-200 border border-rose-800/50 transition-colors">
                <i class="fa-solid fa-right-from-bracket"></i> Keluar
            </a>
        </div>
    </div>
</div>

<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
    
    <!-- Title & Controls -->
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
            <h1 class="text-3xl font-black text-slate-900">Kelola Data Pemilih Tetap (DPT)</h1>
            <p class="text-sm text-slate-500 mt-1">Daftar warga yang berhak memilih di setiap TPS.</p>
        </div>

        <div class="flex flex-wrap gap-2">
            <button type="button" onclick="openAddVoterModal()" class="inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs px-4 py-2.5 rounded-xl shadow-md transition-all">
                <i class="fa-solid fa-user-plus"></i> Tambah Pemilih Baru
            </button>
            <form action="<?= base_url('admin/voters/generate') ?>" method="POST" class="inline-flex">
                <input type="hidden" name="count" value="10">
                <button type="submit" class="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-xs px-4 py-2.5 rounded-xl shadow-md transition-all">
                    <i class="fa-solid fa-wand-magic-sparkles"></i> Generate 10 Pemilih Sampel
                </button>
            </form>
        </div>
    </div>

    <!-- Stats Summary Cards -->
    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4">
            <div class="w-12 h-12 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center text-xl font-bold">
                <i class="fa-solid fa-users"></i>
            </div>
            <div>
                <span class="text-xs font-bold text-slate-400 uppercase">Total DPT</span>
                <h4 class="text-2xl font-extrabold text-slate-900"><?= number_format($total_voters, 0, ',', '.') ?></h4>
            </div>
        </div>

        <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4">
            <div class="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center text-xl font-bold">
                <i class="fa-solid fa-check-double"></i>
            </div>
            <div>
                <span class="text-xs font-bold text-emerald-600 uppercase">Sudah Memilih</span>
                <h4 class="text-2xl font-extrabold text-emerald-600"><?= number_format($total_voted, 0, ',', '.') ?></h4>
            </div>
        </div>

        <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4">
            <div class="w-12 h-12 bg-amber-50 text-amber-600 rounded-xl flex items-center justify-center text-xl font-bold">
                <i class="fa-solid fa-clock"></i>
            </div>
            <div>
                <span class="text-xs font-bold text-amber-600 uppercase">Belum Memilih</span>
                <h4 class="text-2xl font-extrabold text-amber-600"><?= number_format(max(0, $total_voters - $total_voted), 0, ',', '.') ?></h4>
            </div>
        </div>
    </div>

    <!-- DPT Table -->
    <div class="bg-white rounded-3xl shadow-sm border border-slate-200 p-6 sm:p-8">
        <div class="flex justify-between items-center pb-4 border-b border-slate-100 mb-6">
            <h3 class="text-xl font-extrabold text-slate-900">Tabel Data Pemilih Tetap (DPT)</h3>
            <span class="text-xs text-slate-500 font-medium">Total: <?= count($voters) ?> Data</span>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left text-xs text-slate-600">
                <thead class="bg-slate-50 uppercase text-slate-400 font-bold border-b border-slate-100">
                    <tr>
                        <th class="py-3.5 px-4">No.</th>
                        <th class="py-3.5 px-4">NIK Pemilih</th>
                        <th class="py-3.5 px-4">Nama Lengkap Pemilih</th>
                        <th class="py-3.5 px-4">Wilayah RT / RW</th>
                        <th class="py-3.5 px-4 text-center">TPS</th>
                        <th class="py-3.5 px-4 text-center">Status Pemilihan</th>
                        <th class="py-3.5 px-4">Waktu Memilih</th>
                        <th class="py-3.5 px-4 text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php $no = 1; foreach ($voters as $v): ?>
                        <tr class="hover:bg-slate-50 transition-colors">
                            <td class="py-3.5 px-4 text-slate-400 font-bold"><?= $no++ ?></td>
                            <td class="py-3.5 px-4 font-mono font-extrabold text-slate-900 text-sm"><?= htmlspecialchars($v['nik']) ?></td>
                            <td class="py-3.5 px-4 font-bold text-slate-800 text-sm"><?= htmlspecialchars($v['name']) ?></td>
                            <td class="py-3.5 px-4 font-medium text-slate-600"><?= htmlspecialchars($v['rt_rw']) ?></td>
                            <td class="py-3.5 px-4 text-center">
                                <span class="bg-indigo-100 text-indigo-800 font-extrabold px-3 py-1 rounded-full text-[11px] inline-flex items-center">
                                    TPS <?= $v['tps_number'] ?? 1 ?>
                                </span>
                            </td>
                            <td class="py-3.5 px-4 text-center">
                                <?php if ($v['is_voted'] == 1): ?>
                                    <span class="bg-emerald-100 text-emerald-800 font-extrabold px-3 py-1 rounded-full text-[11px] inline-flex items-center gap-1">
                                        <i class="fa-solid fa-check"></i> Sudah Memilih
                                    </span>
                                <?php else: ?>
                                    <span class="bg-slate-100 text-slate-600 font-bold px-3 py-1 rounded-full text-[11px] inline-flex items-center gap-1">
                                        <i class="fa-solid fa-hourglass"></i> Belum Memilih
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td class="py-3.5 px-4 text-slate-500 font-mono">
                                <?= !empty($v['voted_at']) ? date('d-m-Y H:i:s', strtotime($v['voted_at'])) : '-' ?>
                            </td>
                            <td class="py-3.5 px-4 text-center">
                                <button type="button" onclick="confirmDeleteVoter(<?= $v['id'] ?>, '<?= htmlspecialchars($v['name']) ?>')" class="p-2 text-rose-600 hover:bg-rose-50 rounded-lg transition-colors" title="Hapus Pemilih">
                                    <i class="fa-solid fa-trash text-sm"></i>
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<!-- Modal Form Tambah Pemilih -->
<div id="modal-add-voter" class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 hidden">
    <div class="bg-white rounded-3xl shadow-2xl max-w-md w-full p-6 sm:p-8">
        <div class="flex justify-between items-center pb-4 border-b border-slate-100 mb-4">
            <h3 class="text-xl font-extrabold text-slate-900">Tambah Data Pemilih (DPT)</h3>
            <button onclick="closeAddVoterModal()" class="text-slate-400 hover:text-slate-600 text-xl font-bold">&times;</button>
        </div>

        <form action="<?= base_url('admin/voters/add') ?>" method="POST" class="space-y-4">
            <div>
                <label class="block text-xs font-bold uppercase text-slate-700 mb-1">NIK 16 Digit / Kode Akses</label>
                <input type="text" name="nik" required placeholder="Contoh: 3171010101900011" class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono text-sm font-bold text-slate-900">
            </div>

            <div>
                <label class="block text-xs font-bold uppercase text-slate-700 mb-1">Nama Lengkap Pemilih</label>
                <input type="text" name="name" required placeholder="Contoh: Ahmad Fauzi" class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-900">
            </div>

            <div>
                <label class="block text-xs font-bold uppercase text-slate-700 mb-1">Wilayah RT / RW</label>
                <input type="text" name="rt_rw" value="RT 01 / RW 01" required class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900">
            </div>

            <div>
                <label class="block text-xs font-bold uppercase text-slate-700 mb-1">Pilih TPS</label>
                <select name="tps_number" required class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 font-bold">
                    <?php for($i=1; $i<=12; $i++): ?>
                        <option value="<?= $i ?>">TPS <?= $i ?></option>
                    <?php endfor; ?>
                </select>
            </div>

            <div class="pt-4 flex justify-end gap-3 border-t border-slate-100">
                <button type="button" onclick="closeAddVoterModal()" class="px-5 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50">Batal</button>
                <button type="submit" class="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md">Simpan Pemilih</button>
            </div>
        </form>
    </div>
</div>

<script>
    function openAddVoterModal() {
        document.getElementById('modal-add-voter').classList.remove('hidden');
    }
    function closeAddVoterModal() {
        document.getElementById('modal-add-voter').classList.add('hidden');
    }
    function confirmDeleteVoter(id, name) {
        Swal.fire({
            title: 'Hapus Pemilih?',
            text: 'Apakah Anda yakin ingin menghapus data pemilih: ' + name + '?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#e11d48',
            cancelButtonColor: '#64748b',
            confirmButtonText: 'Ya, Hapus!',
            cancelButtonText: 'Batal',
            customClass: { popup: 'rounded-3xl' }
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = '<?= base_url('admin/voters/delete/') ?>' + id;
            }
        });
    }
</script>
