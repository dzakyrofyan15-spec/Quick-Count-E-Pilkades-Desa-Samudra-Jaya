<!-- Admin Top Navigation Subbar -->
<div class="bg-slate-900 text-white border-b border-slate-800 py-3 px-4 sm:px-6 lg:px-8">
    <div class="max-w-7xl mx-auto flex flex-wrap justify-between items-center gap-4">
        <div class="flex items-center gap-3">
            <span class="bg-amber-500/20 text-amber-400 border border-amber-500/30 px-3 py-1 rounded-lg text-xs font-bold uppercase tracking-wider">
                <i class="fa-solid fa-user-shield mr-1"></i> Mode Admin Panitia
            </span>
            <span class="text-sm font-semibold text-slate-300 hidden sm:inline">
                Login sebagai: <strong class="text-white"><?= htmlspecialchars($this->session->userdata('admin_name')) ?></strong>
            </span>
        </div>

        <div class="flex flex-wrap items-center gap-2">
            <a href="<?= base_url('admin/dashboard') ?>" class="px-3 py-1.5 rounded-lg text-xs font-bold bg-amber-600 text-white">
                <i class="fa-solid fa-gauge mr-1"></i> Dashboard
            </a>
            <a href="<?= base_url('admin/candidates') ?>" class="px-3 py-1.5 rounded-lg text-xs font-bold text-slate-300 hover:text-white hover:bg-slate-800 transition-colors">
                <i class="fa-solid fa-users-gear mr-1"></i> Kelola Calon & Foto
            </a>
            <a href="<?= base_url('admin/tps_officers') ?>" class="px-3 py-1.5 rounded-lg text-xs font-bold text-slate-300 hover:text-white hover:bg-slate-800 transition-colors">
                <i class="fa-solid fa-users-viewfinder mr-1"></i> Kelola TPS
            </a>
            <a href="<?= base_url('admin/print_report') ?>" target="_blank" class="px-3 py-1.5 rounded-lg text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors">
                <i class="fa-solid fa-print mr-1"></i> Cetak Berita Acara
            </a>
            <a href="<?= base_url('admin/logout') ?>" class="px-3 py-1.5 rounded-lg text-xs font-bold bg-rose-900/60 hover:bg-rose-800 text-rose-200 border border-rose-800/50 transition-colors">
                <i class="fa-solid fa-right-from-bracket"></i> Keluar
            </a>
        </div>
    </div>
</div>

<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
    
    <!-- Title & Quick Actions Bar -->
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <h1 class="text-3xl font-black text-slate-900">Dashboard Monitoring Pemilihan</h1>
            <p class="text-sm text-slate-500 mt-1">Pantau perolehan suara yang masuk secara langsung dan kelola seluruh jalannya Pilkades.</p>
        </div>

        <div class="flex items-center gap-3">
            <a href="<?= base_url('admin/candidates') ?>" class="inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-extrabold px-4 py-2.5 rounded-xl shadow-md transition-all">
                <i class="fa-solid fa-plus"></i> Tambah Calon Baru
            </a>
        </div>
    </div>

    <!-- Stat Counter Cards -->
    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
            <span class="text-xs font-bold text-slate-400 uppercase tracking-wider">Total TPS</span>
            <div class="text-3xl font-extrabold text-slate-900 mt-1" id="stat-total-tps">12</div>
            <span class="text-xs text-slate-500 mt-1 block">TPS Terdaftar</span>
        </div>

        <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
            <span class="text-xs font-bold text-emerald-600 uppercase tracking-wider">Suara Masuk</span>
            <div class="text-3xl font-extrabold text-emerald-600 mt-1" id="stat-total-voted"><?= number_format($stats['total_voted'], 0, ',', '.') ?></div>
            <span class="text-xs text-emerald-600 mt-1 block font-medium">Suara Sah Real-Time</span>
        </div>

        <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
            <span class="text-xs font-bold text-amber-600 uppercase tracking-wider">Tingkat Partisipasi</span>
            <div class="text-3xl font-extrabold text-amber-600 mt-1" id="stat-participation-percentage"><?= $stats['participation_percentage'] ?>%</div>
            <span class="text-xs text-amber-600 mt-1 block font-medium">Dari Total DPT</span>
        </div>
    </div>

    <!-- Live Candidate Voting Summary Table -->
    <div class="bg-white rounded-3xl shadow-sm border border-slate-200 p-6 sm:p-8">
        <div class="flex justify-between items-center pb-6 border-b border-slate-100 mb-6">
            <div>
                <h3 class="text-xl font-extrabold text-slate-900">Perolehan Suara Calon Kepala Desa</h3>
                <p class="text-xs text-slate-500 mt-0.5">Perhitungan otomatis langsung dari suara pemilih di bilik suara digital.</p>
            </div>
            <a href="<?= base_url('admin/candidates') ?>" class="text-xs font-bold text-emerald-600 hover:text-emerald-700">
                Kelola Calon & Upload Foto &rarr;
            </a>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-6">
            <?php foreach ($stats['candidates'] as $cand): ?>
                <div class="bg-slate-50 p-3 sm:p-5 rounded-2xl border border-slate-100 flex flex-col items-center text-center gap-2 sm:gap-4 hover:border-emerald-200 transition-colors">
                    <!-- Photo Thumbnail -->
                    <div class="w-16 h-20 rounded-xl overflow-hidden bg-white border border-slate-200 shadow-sm flex-shrink-0">
                        <img src="<?= base_url('uploads/candidates/' . $cand['photo']) ?>" alt="<?= htmlspecialchars($cand['full_name']) ?>" class="w-full h-full object-cover" onerror="this.src='<?= base_url('uploads/candidates/default_candidate.svg') ?>'">
                    </div>

                    <!-- Candidate Name & Progress -->
                    <div class="flex-grow w-full">
                        <div class="flex justify-between items-center mb-2">
                            <div class="text-left">
                                <span class="bg-slate-900 text-white font-mono text-[10px] font-extrabold px-2 py-0.5 rounded mr-1">0<?= $cand['candidate_number'] ?></span>
                                <span class="font-extrabold text-slate-900 text-sm line-clamp-1"><?= htmlspecialchars($cand['full_name']) ?></span>
                            </div>
                            <div class="text-right flex-shrink-0">
                                <span id="cand-vote-count-<?= $cand['id'] ?>" class="text-base font-black text-emerald-600">
                                    <?= number_format($cand['vote_count'], 0, ',', '.') ?>
                                </span>
                                <span id="cand-vote-pct-<?= $cand['id'] ?>" class="text-[10px] font-bold text-slate-500 ml-1">
                                    (<?= $cand['percentage'] ?>%)
                                </span>
                            </div>
                        </div>

                        <!-- Progress Bar -->
                        <div class="w-full bg-slate-200 h-3 rounded-full overflow-hidden flex">
                            <div id="cand-vote-bar-<?= $cand['id'] ?>" class="bg-emerald-500 h-full rounded-full transition-all duration-500" style="width: <?= $cand['percentage'] ?>%"></div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- TPS Summary & Audit Log -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        <!-- Status Input per TPS -->
        <div class="lg:col-span-2 bg-white rounded-3xl shadow-sm border border-slate-200 p-6 sm:p-8">
            <div class="flex justify-between items-center pb-4 border-b border-slate-100 mb-4">
                <h3 class="text-lg font-extrabold text-slate-900">Status Rekapitulasi per TPS</h3>
                <a href="<?= base_url('admin/tps_officers') ?>" class="text-xs font-bold text-emerald-600 hover:text-emerald-700">Kelola Akun TPS &rarr;</a>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs text-slate-600">
                    <thead class="bg-slate-50 uppercase text-slate-400 font-bold border-b border-slate-100">
                        <tr>
                            <th class="py-3 px-4">TPS</th>
                            <th class="py-3 px-4 text-center">Status Input</th>
                            <th class="py-3 px-4 text-right">Suara Masuk</th>
                            <th class="py-3 px-4 text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                        <?php foreach ($tps_summary as $tps): ?>
                            <tr class="hover:bg-slate-50 transition-colors">
                                <td class="py-3 px-4 font-black text-slate-900">TPS <?= $tps['tps_number'] ?></td>
                                <td class="py-3 px-4 text-center">
                                    <?php if ($tps['sudah_input']): ?>
                                        <span class="bg-emerald-100 text-emerald-800 font-extrabold px-2.5 py-1 rounded-md text-[10px] uppercase">
                                            <i class="fa-solid fa-check text-emerald-600 mr-1"></i> Selesai
                                        </span>
                                    <?php else: ?>
                                        <span class="bg-amber-100 text-amber-800 font-bold px-2.5 py-1 rounded-md text-[10px] uppercase">
                                            <i class="fa-solid fa-clock text-amber-600 mr-1"></i> Menunggu
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td class="py-3 px-4 text-right font-bold text-blue-600"><?= $tps['total_suara'] ?></td>
                                <td class="py-3 px-4 text-center">
                                    <?php if ($tps['sudah_input']): ?>
                                        <a href="<?= base_url('admin/reset_tps/' . $tps['tps_number']) ?>" onclick="return confirm('Yakin ingin mereset/menghapus semua suara dari TPS <?= $tps['tps_number'] ?>? Panitia TPS harus menginput ulang.');" class="bg-rose-100 text-rose-700 hover:bg-rose-200 font-bold px-3 py-1.5 rounded-md text-[10px] uppercase transition-colors">
                                            <i class="fa-solid fa-rotate-left mr-1"></i> Reset TPS
                                        </a>
                                    <?php else: ?>
                                        <span class="text-slate-400 text-[10px] italic">-</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Recent Inputs Log -->
        <div class="bg-white rounded-3xl shadow-sm border border-slate-200 p-6 sm:p-8">
            <div class="pb-4 border-b border-slate-100 mb-4">
                <h3 class="text-lg font-extrabold text-slate-900">Log Aktivitas TPS</h3>
            </div>
            
            <div class="space-y-4">
                <?php if (!empty($recent_inputs)): ?>
                    <?php foreach ($recent_inputs as $log): ?>
                        <div class="flex gap-3 items-start">
                            <div class="mt-0.5 w-8 h-8 rounded-full bg-blue-50 text-blue-500 flex items-center justify-center flex-shrink-0">
                                <i class="fa-solid fa-cloud-arrow-up text-xs"></i>
                            </div>
                            <div>
                                <p class="text-sm font-bold text-slate-900">TPS <?= $log['tps_number'] ?> <span class="text-xs font-normal text-slate-500">mengirim data</span></p>
                                <p class="text-xs text-slate-500">Total <strong class="text-emerald-600"><?= $log['total_suara'] ?> suara</strong></p>
                                <p class="text-[10px] text-slate-400 mt-0.5"><i class="fa-regular fa-clock"></i> <?= date('d M Y, H:i', strtotime($log['input_at'])) ?> oleh <?= htmlspecialchars($log['officer_name']) ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="text-center text-slate-400 italic text-sm">Belum ada data suara masuk.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

</div>


