<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Berita Acara Perhitungan Suara Pilkades Samudrajaya</title>
    <style>
        body {
            font-family: 'Times New Roman', Times, serif;
            color: #000;
            line-height: 1.5;
            padding: 20px;
            background: #fff;
        }
        .header {
            text-align: center;
            border-bottom: 3px double #000;
            padding-bottom: 12px;
            margin-bottom: 24px;
        }
        .header h3 {
            margin: 0;
            font-size: 16pt;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .header h2 {
            margin: 4px 0;
            font-size: 18pt;
            text-transform: uppercase;
            font-weight: bold;
        }
        .header p {
            margin: 0;
            font-size: 11pt;
            font-style: italic;
        }
        .doc-title {
            text-align: center;
            font-weight: bold;
            text-transform: uppercase;
            font-size: 14pt;
            margin-bottom: 20px;
            text-decoration: underline;
        }
        table.data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
            margin-bottom: 25px;
        }
        table.data-table th, table.data-table td {
            border: 1px solid #000;
            padding: 8px 12px;
            font-size: 11pt;
        }
        table.data-table th {
            background-color: #f2f2f2;
            text-align: center;
            font-weight: bold;
        }
        .signature-section {
            margin-top: 40px;
            width: 100%;
        }
        .signature-table {
            width: 100%;
            border-collapse: collapse;
        }
        .signature-table td {
            text-align: center;
            vertical-align: top;
            padding: 20px 10px;
        }
        .sign-space {
            height: 70px;
        }
        @media print {
            .no-print {
                display: none !important;
            }
            body {
                padding: 0;
            }
        }
    </style>
</head>
<body>

    <!-- Printable Header Controls -->
    <div class="no-print" style="margin-bottom: 20px; text-align: right;">
        <button onclick="window.print()" style="padding: 10px 20px; background: #059669; color: #fff; border: none; border-radius: 8px; font-weight: bold; cursor: pointer;">
            🖨️ Cetak / Simpan PDF
        </button>
        <button onclick="window.close()" style="padding: 10px 20px; background: #64748b; color: #fff; border: none; border-radius: 8px; font-weight: bold; cursor: pointer; margin-left: 10px;">
            Tutup Halaman
        </button>
    </div>

    <!-- Kop Surat Panitia Pilkades -->
    <div class="header">
        <h3>PANITIA PEMILIHAN KEPALA DESA</h3>
        <h2>DESA MAKMUR SEJAHTERA</h2>
        <p>Alamat: Jl. Raya Desa Makmur No. 01, Kecamatan Sejahtera, Kabupaten Makmur</p>
    </div>

    <div class="doc-title">
        BERITA ACARA HASIL PERHITUNGAN SUARA ELEKTRONIK (E-PILKADES)<br>
        <span style="font-size: 11pt; font-weight: normal; text-decoration: none;">Tahun 2026</span>
    </div>

    <p>
        Pada hari ini <strong><?= date('l') ?></strong>, tanggal <strong><?= date('d F Y') ?></strong>, telah dilaksanakan pemungutan dan perhitungan suara secara langsung berbasis elektronik (E-Voting Direct) untuk Pemilihan Calon Kepala Desa Samudrajaya dengan rincian rekapitulasi data sebagai berikut:
    </p>

    <!-- Tabel Rekapitulasi Umum -->
    <h4 style="margin-bottom: 5px; text-transform: uppercase;">I. REKAPITULASI PEMILIH DAN SUARA</h4>
    <table class="data-table">
        <tr>
            <td width="5%">1.</td>
            <td>Jumlah Pemilih Tetap (DPT) Terdaftar</td>
            <td width="20%" align="right"><strong><?= number_format($stats['total_voters'], 0, ',', '.') ?></strong> Orang</td>
        </tr>
        <tr>
            <td>2.</td>
            <td>Jumlah Suara Masuk (Suara Sah)</td>
            <td align="right"><strong><?= number_format($stats['total_voted'], 0, ',', '.') ?></strong> Suara</td>
        </tr>
        <tr>
            <td>3.</td>
            <td>Jumlah Sisa Hak Suara / Belum Memilih</td>
            <td align="right"><strong><?= number_format($stats['total_unvoted'], 0, ',', '.') ?></strong> Suara</td>
        </tr>
        <tr>
            <td>4.</td>
            <td>Persentase Partisipasi Masyarakat</td>
            <td align="right"><strong><?= $stats['participation_percentage'] ?> %</strong></td>
        </tr>
    </table>

    <!-- Tabel Perolehan Suara Calon -->
    <h4 style="margin-bottom: 5px; text-transform: uppercase;">II. HASIL PEROLEHAN SUARA CALON KEPALA DESA</h4>
    <table class="data-table">
        <thead>
            <tr>
                <th width="10%">No. Urut</th>
                <th>Nama Lengkap Calon Kepala Desa</th>
                <th width="20%">Jumlah Perolehan Suara</th>
                <th width="20%">Persentase (%)</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($stats['candidates'] as $cand): ?>
                <tr>
                    <td align="center"><strong>0<?= $cand['candidate_number'] ?></strong></td>
                    <td><strong><?= htmlspecialchars($cand['full_name']) ?></strong></td>
                    <td align="right"><strong><?= number_format($cand['vote_count'], 0, ',', '.') ?></strong> Suara</td>
                    <td align="right"><strong><?= $cand['percentage'] ?> %</strong></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <!-- Tabel Rincian Suara per TPS -->
    <h4 style="margin-bottom: 5px; margin-top: 24px; text-transform: uppercase;">III. RINCIAN PEROLEHAN SUARA PER TPS</h4>
    <table class="data-table">
        <thead>
            <tr>
                <th width="8%">TPS</th>
                <?php foreach ($stats['candidates'] as $cand): ?>
                    <th>Calon No. 0<?= $cand['candidate_number'] ?><br><small style="font-size:9pt;"><?= htmlspecialchars($cand['full_name']) ?></small></th>
                <?php endforeach; ?>
                <th width="12%">Total Suara</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $grandTotal = array_fill(0, count($stats['candidates']), 0);
            for ($t = 1; $t <= 12; $t++):
                $rowTotal = 0;
            ?>
                <tr>
                    <td align="center"><strong>TPS <?= $t ?></strong></td>
                    <?php foreach ($stats['candidates'] as $idx => $cand):
                        $tpsVote = isset($cand['tps_breakdown'][$t]) ? (int)$cand['tps_breakdown'][$t] : 0;
                        $grandTotal[$idx] += $tpsVote;
                        $rowTotal += $tpsVote;
                    ?>
                        <td align="center"><?= number_format($tpsVote, 0, ',', '.') ?></td>
                    <?php endforeach; ?>
                    <td align="center"><strong><?= number_format($rowTotal, 0, ',', '.') ?></strong></td>
                </tr>
            <?php endfor; ?>
        </tbody>
        <tfoot>
            <tr style="background:#e8f5e9; font-weight:bold;">
                <td align="center"><strong>TOTAL</strong></td>
                <?php foreach ($stats['candidates'] as $idx => $cand): ?>
                    <td align="center"><strong><?= number_format($grandTotal[$idx], 0, ',', '.') ?></strong></td>
                <?php endforeach; ?>
                <td align="center"><strong><?= number_format($stats['total_voted'], 0, ',', '.') ?></strong></td>
            </tr>
        </tfoot>
    </table>

    <p>
        Demikian Berita Acara Perhitungan Suara Pemilihan Kepala Desa ini dibuat dengan sebenarnya sesuai dengan data sistem E-Pilkades untuk dipergunakan sebagaimana mestinya.
    </p>

    <!-- Tanda Tangan Panitia & Saksi -->
    <div class="signature-section">
        <table class="signature-table">
            <tr>
                <td width="33%">
                    Mengetahui,<br>
                    <strong>Ketua Panitia Pilkades</strong>
                    <div class="sign-space"></div>
                    <strong>( H. M. Ridwan, S.H. )</strong>
                </td>
                <td width="33%">
                    Saksi Calon 01 / 02
                    <div class="sign-space"></div>
                    <strong>( ........................................... )</strong>
                </td>
                <td width="33%">
                    Samudrajaya, <?= date('d F Y') ?><br>
                    <strong>Sekretaris Panitia</strong>
                    <div class="sign-space"></div>
                    <strong>( Drs. H. Sukardi )</strong>
                </td>
            </tr>
        </table>
    </div>

    <script>
        window.onload = function() {
            // Auto trigger print when loaded
            setTimeout(function() {
                window.print();
            }, 500);
        };
    </script>
</body>
</html>
