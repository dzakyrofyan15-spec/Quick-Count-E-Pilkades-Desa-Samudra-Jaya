<div class="min-h-[80vh] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
    <div class="max-w-md w-full space-y-8 bg-white p-8 rounded-3xl shadow-2xl border border-slate-100">
        
        <div class="text-center space-y-3">
            <div class="w-16 h-16 bg-amber-50 rounded-2xl flex items-center justify-center text-amber-600 text-3xl mx-auto shadow-inner">
                <i class="fa-solid fa-user-shield"></i>
            </div>
            <h2 class="text-3xl font-extrabold text-slate-900 tracking-tight">Portal Panitia Admin</h2>
            <p class="text-xs text-slate-500">
                Masuk untuk mengelola data calon kepala desa, upload foto, data DPT pemilih, dan laporan hasil suara.
            </p>
        </div>

        <form action="<?= base_url('admin/login') ?>" method="POST" class="mt-8 space-y-5">
            <div>
                <label for="username" class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                    Username Panitia
                </label>
                <div class="relative rounded-xl shadow-sm">
                    <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                        <i class="fa-solid fa-user"></i>
                    </div>
                    <input type="text" id="username" name="username" required value="admin" class="block w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white transition-all">
                </div>
            </div>

            <div>
                <label for="password" class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                    Password
                </label>
                <div class="relative rounded-xl shadow-sm">
                    <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                        <i class="fa-solid fa-key"></i>
                    </div>
                    <input type="password" id="password" name="password" required value="admin123" class="block w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white transition-all">
                </div>
            </div>

            <button type="submit" class="w-full flex justify-center items-center gap-2 py-3.5 px-4 border border-transparent text-sm font-bold rounded-xl text-white bg-amber-600 hover:bg-amber-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-amber-500 shadow-lg shadow-amber-600/30 transition-all">
                <i class="fa-solid fa-right-to-bracket"></i> Masuk Dashboard Admin
            </button>
        </form>

        <div class="pt-4 border-t border-slate-100 text-center">
            <p class="text-xs text-slate-400">
                Akun Standar Panitia: <span class="font-mono text-slate-700 font-bold">admin</span> / <span class="font-mono text-slate-700 font-bold">admin123</span>
            </p>
        </div>

    </div>
</div>
