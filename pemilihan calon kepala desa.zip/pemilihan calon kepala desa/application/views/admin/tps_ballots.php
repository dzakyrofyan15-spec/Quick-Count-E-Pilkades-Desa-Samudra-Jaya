<div class="bg-slate-900 text-white border-b border-slate-800 py-3 px-4 sm:px-6 lg:px-8">
    <div class="max-w-7xl mx-auto flex flex-wrap justify-between items-center gap-4">
        <div class="flex items-center gap-3">
            <span class="bg-amber-500/20 text-amber-400 border border-amber-500/30 px-3 py-1 rounded-lg text-xs font-bold uppercase tracking-wider">
                <i class="fa-solid fa-box-archive mr-1"></i> Audit Suara TPS
            </span>
            <span class="text-sm font-semibold text-slate-300">
                Data Surat Suara <strong class="text-white">TPS <?= $tps_number ?></strong>
            </span>
        </div>
        <div>
            <a href="<?= base_url('admin/dashboard') ?>" class="px-4 py-2 rounded-lg text-xs font-bold text-white bg-slate-800 hover:bg-slate-700 transition-colors">
                &larr; Kembali ke Dashboard
            </a>
        </div>
    </div>
</div>

<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
    <div class="bg-white rounded-3xl shadow-sm border border-slate-200 p-6 sm:p-8">
        <div class="flex justify-between items-center mb-6 pb-4 border-b border-slate-100">
            <div>
                <h2 class="text-2xl font-black text-slate-900">Galeri Surat Suara TPS <?= $tps_number ?></h2>
                <p class="text-sm text-slate-500">Berikut adalah bukti fisik lembar kertas suara yang telah diinputkan oleh panitia TPS.</p>
            </div>
            <div class="text-right">
                <div class="text-sm text-slate-500">Total Suara Masuk</div>
                <?php
                    $total_suara = 0;
                    foreach ($ballots as $b) {
                        $total_suara += (int)$b['vote_count'];
                    }
                ?>
                <div class="text-3xl font-black text-blue-600"><?= $total_suara ?></div>
            </div>
        </div>

        <?php if (!empty($ballots)): ?>
            <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
                <?php foreach ($ballots as $ballot): ?>
                    <div class="bg-slate-50 rounded-2xl border border-slate-200 overflow-hidden group hover:border-blue-300 transition-colors shadow-sm">
                        <a href="<?= base_url('uploads/evidence/' . $ballot['evidence_photo']) ?>" target="_blank" class="block h-48 bg-slate-200 overflow-hidden relative">
                            <img src="<?= base_url('uploads/evidence/' . $ballot['evidence_photo']) ?>" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300">
                            <div class="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                <span class="text-white font-bold text-sm bg-black/60 px-3 py-1.5 rounded-lg"><i class="fa-solid fa-magnifying-glass mr-1"></i> Perbesar</span>
                            </div>
                        </a>
                        <div class="p-4 text-center">
                            <span class="bg-slate-800 text-white text-[10px] font-bold px-2 py-0.5 rounded block w-max mx-auto mb-2">0<?= $ballot['candidate_number'] ?></span>
                            <div class="font-bold text-slate-900 text-xs line-clamp-1 mb-1"><?= htmlspecialchars($ballot['full_name']) ?></div>
                            <div class="text-[11px] font-bold text-blue-600 mb-1"><?= $ballot['vote_count'] ?> Suara</div>
                            <div class="text-[10px] text-slate-400 border-t border-slate-200 pt-2 mt-2"><i class="fa-regular fa-clock"></i> <?= date('d M Y, H:i', strtotime($ballot['created_at'])) ?></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="text-center py-20 bg-slate-50 rounded-3xl border-2 border-slate-200 border-dashed">
                <i class="fa-solid fa-box-open text-6xl text-slate-300 mb-4 block"></i>
                <h3 class="text-xl font-bold text-slate-700 mb-2">Belum Ada Suara</h3>
                <p class="text-slate-500">TPS ini belum menginput satu pun surat suara.</p>
            </div>
        <?php endif; ?>
    </div>
</div>
