    </main>

    <!-- Footer -->
    <footer class="bg-slate-900 text-slate-400 border-t border-slate-800 mt-16 py-8">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center sm:text-left flex flex-col sm:flex-row justify-between items-center gap-4">
            <div>
                <p class="text-sm font-semibold text-slate-200">
                    Sistem Pemilihan Kepala Desa (E-Pilkades) Direct Realtime
                </p>
                <p class="text-xs text-slate-500 mt-1">
                    &copy; <?= date('Y') ?> Panitia Pemilihan Kepala Desa Samudrajaya. Hak Cipta Dilindungi Undang-Undang.
                </p>
            </div>
            <div class="flex items-center space-x-4 text-xs">
                <span class="text-emerald-400 font-medium">
                    <i class="fa-solid fa-lock text-xs mr-1"></i> Terenkripsi & Transparan
                </span>
                <span class="text-slate-600">|</span>
                <a href="<?= base_url('admin') ?>" class="text-slate-400 hover:text-white transition-colors">Portal Panitia Admin</a>
            </div>
        </div>
    </footer>

    <!-- Global Live Quick Count Update Script -->
    <script>
        const BASE_URL = '<?= base_url() ?>';

        // Auto polling live stats every 3 seconds if stats container exists
        let pollingInterval = null;

        function fetchLiveCountData() {
            fetch(BASE_URL + 'api/live_count')
                .then(response => response.json())
                .then(res => {
                    if (res.status === 'success') {
                        const data = res.data;
                        
                        // Update counter elements if present in DOM
                        const elTotalVoters = document.getElementById('stat-total-voters');
                        const elTotalVoted = document.getElementById('stat-total-voted');
                        const elTotalUnvoted = document.getElementById('stat-total-unvoted');
                        const elPercentage = document.getElementById('stat-participation-percentage');
                        const elProgressBar = document.getElementById('stat-participation-progress');

                        if (elTotalVoters) elTotalVoters.textContent = data.total_voters.toLocaleString('id-ID');
                        if (elTotalVoted) elTotalVoted.textContent = data.total_voted.toLocaleString('id-ID');
                        if (elTotalUnvoted) elTotalUnvoted.textContent = data.total_unvoted.toLocaleString('id-ID');
                        if (elPercentage) elPercentage.textContent = data.participation_percentage + '%';
                        if (elProgressBar) elProgressBar.style.width = data.participation_percentage + '%';

                        // Update candidate cards vote count & percentage badges
                        if (data.candidates && Array.isArray(data.candidates)) {
                            data.candidates.forEach(cand => {
                                const badgeCount = document.getElementById('cand-vote-count-' + cand.id);
                                const badgePct = document.getElementById('cand-vote-pct-' + cand.id);
                                const barWidth = document.getElementById('cand-vote-bar-' + cand.id);

                                if (badgeCount) badgeCount.textContent = cand.vote_count.toLocaleString('id-ID') + ' Suara';
                                if (badgePct) badgePct.textContent = cand.percentage + '%';
                                if (barWidth) barWidth.style.width = cand.percentage + '%';

                                // Update TPS breakdown
                                if (cand.tps_breakdown) {
                                    for (let t = 1; t <= 12; t++) {
                                        const elTps = document.getElementById('cand-' + cand.id + '-tps-' + t);
                                        if (elTps && cand.tps_breakdown[t] !== undefined) {
                                            elTps.textContent = cand.tps_breakdown[t].toLocaleString('id-ID');
                                        }
                                    }
                                }
                            });
                        }

                        // Trigger Chart.js update if globally registered
                    }
                })
                .catch(err => console.log('Polling live count error:', err));
        }

        document.addEventListener('DOMContentLoaded', () => {
            // Start polling live data
            fetchLiveCountData();
            pollingInterval = setInterval(fetchLiveCountData, 3000);

            // Auto-logout Inactivity Timer (10 minutes)
            let inactivityTime = function () {
                let time;
                
                // Reset timer on any user interaction
                window.onload = resetTimer;
                document.onmousemove = resetTimer;
                document.onkeypress = resetTimer;
                document.ontouchstart = resetTimer;
                document.onclick = resetTimer;
                document.onscroll = resetTimer;

                function logout() {
                    // Refresh the page, CI will handle redirecting to login since session expired
                    window.location.reload();
                }

                function resetTimer() {
                    clearTimeout(time);
                    time = setTimeout(logout, 600000); // 600,000 ms = 10 minutes
                }
            };
            
            // Only run inactivity timer if a user is logged in
            <?php if ($this->session->userdata('admin_logged_in') || $this->session->userdata('tps_logged_in') || $this->session->userdata('voter_logged_in')): ?>
                inactivityTime();
            <?php endif; ?>
        });
    </script>
</body>
</html>
