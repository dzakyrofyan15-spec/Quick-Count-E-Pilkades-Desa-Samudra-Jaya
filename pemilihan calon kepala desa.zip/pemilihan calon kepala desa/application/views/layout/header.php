<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($title) ? htmlspecialchars($title) : 'PilKaDeS Online' ?></title>
    
    <!-- Google Fonts: Plus Jakarta Sans & Inter -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- FontAwesome 6 Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Tailwind CSS (CDN) -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        emerald: {
                            50: '#ecfdf5',
                            100: '#d1fae5',
                            500: '#10b981',
                            600: '#059669',
                            700: '#047857',
                            800: '#065f46',
                            900: '#064e3b',
                        },
                        navy: {
                            800: '#1e293b',
                            900: '#0f172a',
                        }
                    },
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', 'sans-serif'],
                    }
                }
            }
        }
    </script>
    
    <!-- Chart.js & SweetAlert2 -->

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <style>
        .glass-card {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.3);
        }
        .pulse-live {
            animation: pulse-ring 1.5s cubic-bezier(0.215, 0.61, 0.355, 1) infinite;
        }
        @keyframes pulse-ring {
            0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7); }
            70% { transform: scale(1); box-shadow: 0 0 0 10px rgba(16, 185, 129, 0); }
            100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(16, 185, 129, 0); }
        }
    </style>
</head>
<body class="bg-slate-50 font-sans text-slate-800 min-h-screen flex flex-col antialiased">

    <!-- Top Navigation Bar -->
    <nav class="bg-slate-900 text-white shadow-lg sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-20">
                
                <!-- Logo & Village Name -->
                <a href="<?= base_url() ?>" class="flex items-center gap-3 group">
                    <div class="w-11 h-11 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-slate-900 font-bold text-xl shadow-md group-hover:scale-105 transition-transform">
                        <i class="fa-solid fa-check-to-slot text-white text-lg"></i>
                    </div>
                    <div>
                        <span class="text-xl font-extrabold tracking-tight bg-gradient-to-r from-white via-slate-100 to-slate-300 bg-clip-text text-transparent">
                            E-PILKADES
                        </span>
                        <span class="block text-xs font-medium text-emerald-400 tracking-wider uppercase">
                            Desa Samudrajaya
                        </span>
                    </div>
                </a>

                <!-- Navigation Links -->
                <div class="hidden md:flex items-center space-x-2">
                    <a href="<?= base_url() ?>" class="px-4 py-2 rounded-lg text-sm font-semibold transition-colors <?= ($this->uri->segment(1) == '' || $this->uri->segment(1) == 'home') ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-300 hover:text-white hover:bg-slate-800' ?>">
                        <i class="fa-solid fa-chart-pie mr-1.5"></i> Live Quick Count
                    </a>

                    <?php if ($this->session->userdata('tps_logged_in')): ?>
                        <a href="<?= base_url('tps/dashboard') ?>" class="px-4 py-2 rounded-lg text-sm font-semibold transition-colors <?= ($this->uri->segment(1) == 'tps') ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-300 hover:text-white hover:bg-slate-800' ?>">
                            <i class="fa-solid fa-users-viewfinder mr-1.5"></i> Panel TPS <?= $this->session->userdata('tps_number') ?>
                        </a>
                    <?php else: ?>
                        <a href="<?= base_url('tps/login') ?>" class="px-4 py-2 rounded-lg text-sm font-semibold transition-colors <?= ($this->uri->segment(1) == 'tps') ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-300 hover:text-white hover:bg-slate-800' ?>">
                            <i class="fa-solid fa-users-gear mr-1.5"></i> Login TPS
                        </a>
                    <?php endif; ?>

                    <?php if ($this->session->userdata('admin_logged_in')): ?>
                        <a href="<?= base_url('admin/dashboard') ?>" class="px-4 py-2 rounded-lg text-sm font-semibold transition-colors <?= ($this->uri->segment(1) == 'admin') ? 'bg-amber-600 text-white shadow-sm' : 'text-slate-300 hover:text-white hover:bg-slate-800' ?>">
                            <i class="fa-solid fa-user-shield mr-1.5"></i> Admin Pusat
                        </a>
                    <?php else: ?>
                        <a href="<?= base_url('admin/login') ?>" class="px-4 py-2 rounded-lg text-sm font-semibold text-slate-400 hover:text-white hover:bg-slate-800 transition-colors">
                            <i class="fa-solid fa-lock mr-1.5"></i> Admin Pusat
                        </a>
                    <?php endif; ?>
                </div>

                <!-- Live Indicator Pill & Mobile Toggle -->
                <div class="flex items-center gap-2 sm:gap-3">
                    <div class="flex items-center gap-2 bg-slate-800 px-2 sm:px-3 py-1.5 rounded-full border border-slate-700">
                        <span class="w-2.5 h-2.5 rounded-full bg-emerald-500 pulse-live"></span>
                        <span class="text-[10px] sm:text-xs font-semibold text-emerald-400 tracking-wide hidden sm:inline">SYSTEM REALTIME</span>
                    </div>

                    <?php if ($this->session->userdata('voter_logged_in')): ?>
                        <a href="<?= base_url('vote/logout') ?>" class="text-[10px] sm:text-xs font-bold bg-rose-600 hover:bg-rose-700 text-white px-2 sm:px-3 py-1.5 rounded-lg transition-colors">
                            Keluar
                        </a>
                    <?php endif; ?>

                    <!-- Mobile Menu Button -->
                    <button id="mobileMenuBtn" class="md:hidden text-slate-300 hover:text-white p-2">
                        <i class="fa-solid fa-bars text-xl"></i>
                    </button>
                </div>

            </div>
        </div>

        <!-- Mobile Menu Dropdown -->
        <div id="mobileMenu" class="hidden md:hidden bg-slate-800 border-t border-slate-700">
            <div class="px-4 pt-2 pb-4 space-y-1">
                <a href="<?= base_url() ?>" class="block px-3 py-2 rounded-lg text-sm font-semibold transition-colors <?= ($this->uri->segment(1) == '' || $this->uri->segment(1) == 'home') ? 'bg-emerald-600 text-white' : 'text-slate-300 hover:text-white hover:bg-slate-700' ?>">
                    <i class="fa-solid fa-chart-pie w-5 text-center mr-1"></i> Live Quick Count
                </a>

                <?php if ($this->session->userdata('tps_logged_in')): ?>
                    <a href="<?= base_url('tps/dashboard') ?>" class="block px-3 py-2 rounded-lg text-sm font-semibold transition-colors <?= ($this->uri->segment(1) == 'tps') ? 'bg-blue-600 text-white' : 'text-slate-300 hover:text-white hover:bg-slate-700' ?>">
                        <i class="fa-solid fa-users-viewfinder w-5 text-center mr-1"></i> Panel TPS <?= $this->session->userdata('tps_number') ?>
                    </a>
                <?php else: ?>
                    <a href="<?= base_url('tps/login') ?>" class="block px-3 py-2 rounded-lg text-sm font-semibold transition-colors <?= ($this->uri->segment(1) == 'tps') ? 'bg-blue-600 text-white' : 'text-slate-300 hover:text-white hover:bg-slate-700' ?>">
                        <i class="fa-solid fa-users-gear w-5 text-center mr-1"></i> Login TPS
                    </a>
                <?php endif; ?>

                <?php if ($this->session->userdata('admin_logged_in')): ?>
                    <a href="<?= base_url('admin/dashboard') ?>" class="block px-3 py-2 rounded-lg text-sm font-semibold transition-colors <?= ($this->uri->segment(1) == 'admin') ? 'bg-amber-600 text-white' : 'text-slate-300 hover:text-white hover:bg-slate-700' ?>">
                        <i class="fa-solid fa-user-shield w-5 text-center mr-1"></i> Admin Pusat
                    </a>
                <?php else: ?>
                    <a href="<?= base_url('admin/login') ?>" class="block px-3 py-2 rounded-lg text-sm font-semibold text-slate-400 hover:text-white hover:bg-slate-700 transition-colors">
                        <i class="fa-solid fa-lock w-5 text-center mr-1"></i> Admin Pusat
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- Script for mobile menu -->
    <script>
        document.getElementById('mobileMenuBtn').addEventListener('click', function() {
            var menu = document.getElementById('mobileMenu');
            menu.classList.toggle('hidden');
        });
    </script>

    <!-- Alert Notifications -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-4">
        <?php if ($this->session->flashdata('success')): ?>
            <div class="p-4 mb-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-start gap-3 shadow-sm">
                <i class="fa-solid fa-circle-check text-emerald-600 text-xl mt-0.5"></i>
                <div class="font-medium text-sm"><?= $this->session->flashdata('success') ?></div>
            </div>
        <?php endif; ?>

        <?php if ($this->session->flashdata('error')): ?>
            <div class="p-4 mb-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 flex items-start gap-3 shadow-sm">
                <i class="fa-solid fa-triangle-exclamation text-rose-600 text-xl mt-0.5"></i>
                <div class="font-medium text-sm"><?= $this->session->flashdata('error') ?></div>
            </div>
        <?php endif; ?>

        <?php if ($this->session->flashdata('warning')): ?>
            <div class="p-4 mb-4 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 flex items-start gap-3 shadow-sm">
                <i class="fa-solid fa-circle-info text-amber-600 text-xl mt-0.5"></i>
                <div class="font-medium text-sm"><?= $this->session->flashdata('warning') ?></div>
            </div>
        <?php endif; ?>
    </div>

    <!-- Main Content Container -->
    <main class="flex-grow">
