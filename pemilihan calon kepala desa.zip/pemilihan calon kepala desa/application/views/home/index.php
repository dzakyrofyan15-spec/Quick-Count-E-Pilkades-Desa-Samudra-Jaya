<!-- Hero Banner -->
<div class="relative bg-gradient-to-br from-slate-900 via-slate-800 to-emerald-950 text-white py-16 px-4 sm:px-6 lg:px-8 overflow-hidden shadow-xl border-b border-emerald-900/50">
    <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-emerald-500/10 via-transparent to-transparent"></div>
    
    <div class="relative max-w-7xl mx-auto text-center space-y-6">
        <div class="inline-flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/30 px-4 py-1.5 rounded-full text-emerald-400 text-xs sm:text-sm font-semibold tracking-wide uppercase shadow-inner">
            <i class="fa-solid fa-vote-nay text-emerald-400"></i> Perhitungan Cepat Real-Time 2026
        </div>
        
        <h1 class="text-3xl sm:text-5xl font-extrabold tracking-tight text-white max-w-4xl mx-auto leading-tight">
            Perhitungan Cepat Pilkades <span class="bg-gradient-to-r from-emerald-400 to-teal-300 bg-clip-text text-transparent">Samudrajaya 2026</span>
        </h1>
        
        <p class="text-slate-300 text-base sm:text-lg max-w-2xl mx-auto font-normal">
            Selamat datang di portal informasi Publik Desa Samudrajaya. Pantau hasil perolehan suara secara langsung dari seluruh TPS yang diinput oleh <strong class="text-emerald-400 font-semibold">Panitia Resmi</strong>.
        </p>

        <div class="pt-4 flex flex-wrap justify-center gap-4">
            <a href="#candidates" class="inline-flex items-center gap-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-base px-8 py-4 rounded-xl shadow-lg shadow-emerald-600/30 hover:scale-105 active:scale-95 transition-all">
                <i class="fa-solid fa-chart-simple text-xl"></i> Lihat Hasil Live Count
            </a>
        </div>
    </div>
</div>





<!-- Candidate Profiles Section -->
<div id="candidates" class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-16 mb-16">
    <div class="text-center max-w-3xl mx-auto space-y-2 mb-12">
        <h2 class="text-3xl font-extrabold text-slate-900">Daftar Calon Kepala Desa</h2>
        <p class="text-slate-600 text-base">Kenali visi, misi, dan program kerja calon pemimpin desa Anda sebelum menentukan pilihan di bilik suara.</p>
    </div>

    <!-- Candidate Cards Grid -->
    <?php 
        $count = count($candidates);
        $gridClass = 'lg:grid-cols-3'; // default
        $maxWidth = '';
        if ($count == 1) {
            $gridClass = 'lg:grid-cols-1';
            $maxWidth = 'max-w-md mx-auto';
        } elseif ($count == 2) {
            $gridClass = 'lg:grid-cols-2';
            $maxWidth = 'max-w-4xl mx-auto';
        }
    ?>
    <div class="grid grid-cols-2 md:grid-cols-2 <?= $gridClass ?> gap-8 <?= $maxWidth ?>">
        <?php foreach ($candidates as $cand): ?>
            <div class="bg-white rounded-3xl shadow-lg border border-slate-100 overflow-hidden flex flex-col hover:shadow-2xl transition-all duration-300 group">
                
                <!-- Card Header Image & Badge -->
                <div class="relative bg-gradient-to-b from-slate-100 to-slate-200 pt-6 px-6 text-center">
                    
                    <!-- Candidate Number Pill -->
                    <div class="absolute top-4 left-4 bg-slate-900 text-white px-4 py-1.5 rounded-full shadow-md flex items-center gap-2">
                        <span class="text-xs text-emerald-400 uppercase font-extrabold tracking-wider">No. Urut</span>
                        <span class="text-lg font-extrabold text-white">0<?= $cand['candidate_number'] ?></span>
                    </div>

                    <!-- Photo Render -->
                    <div class="w-48 h-56 mx-auto mt-4 overflow-hidden rounded-2xl border-4 border-white shadow-xl bg-white flex items-center justify-center">
                        <img src="<?= base_url('uploads/candidates/' . $cand['photo']) ?>" alt="<?= htmlspecialchars($cand['full_name']) ?>" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" onerror="this.src='<?= base_url('uploads/candidates/default_candidate.svg') ?>'">
                    </div>
                </div>

                <!-- Candidate Info Body -->
                <div class="p-6 flex-grow flex flex-col justify-between space-y-6">
                    <div>
                        <h3 class="text-xl font-extrabold text-slate-900 group-hover:text-emerald-600 transition-colors text-center">
                            <?= htmlspecialchars($cand['full_name']) ?>
                        </h3>
                        
                        <!-- Rincian Suara per TPS -->
                        <div class="mt-6">
                            <h4 class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2 text-center">Rincian Suara per TPS</h4>
                            <div class="grid grid-cols-3 sm:grid-cols-4 gap-2">
                                <?php for ($t = 1; $t <= 12; $t++): ?>
                                    <div class="bg-slate-50 border border-slate-100 rounded-lg p-2 text-center flex flex-col justify-center">
                                        <span class="text-[9px] font-bold text-slate-400 uppercase leading-none">TPS <?= $t ?></span>
                                        <span id="cand-<?= $cand['id'] ?>-tps-<?= $t ?>" class="text-sm font-extrabold text-slate-700 mt-1 leading-none">
                                            <?= isset($cand['tps_breakdown'][$t]) ? number_format($cand['tps_breakdown'][$t], 0, ',', '.') : '0' ?>
                                        </span>
                                    </div>
                                <?php endfor; ?>
                            </div>
                        </div>

                    </div>

                        <!-- Live Vote Bar per Candidate -->
                        <div class="pt-3 sm:pt-4 border-t border-slate-100">
                            <div class="flex justify-between items-center text-[10px] sm:text-xs font-bold mb-1.5">
                                <span class="text-slate-500 uppercase">Suara</span>
                                <span id="cand-vote-count-<?= $cand['id'] ?>" class="text-emerald-700 font-extrabold">
                                    <?= number_format($cand['vote_count'], 0, ',', '.') ?>
                                </span>
                            </div>
                            
                            <div class="w-full bg-slate-100 h-2 sm:h-3 rounded-full overflow-hidden flex items-center">
                                <div id="cand-vote-bar-<?= $cand['id'] ?>" class="bg-emerald-500 h-full rounded-full transition-all duration-500" style="width: <?= ($stats['total_voted'] > 0) ? round(($cand['vote_count'] / $stats['total_voted']) * 100, 1) : 0 ?>%"></div>
                            </div>

                            <div class="text-right mt-1">
                                <span id="cand-vote-pct-<?= $cand['id'] ?>" class="text-[10px] sm:text-xs font-extrabold text-slate-900">
                                    <?= ($stats['total_voted'] > 0) ? round(($cand['vote_count'] / $stats['total_voted']) * 100, 1) : 0 ?>%
                                </span>
                            </div>
                        </div>

                </div>

            </div>
        <?php endforeach; ?>
    </div>
</div>

