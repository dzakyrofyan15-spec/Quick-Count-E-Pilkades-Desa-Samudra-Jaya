<div class="min-h-[80vh] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
    <div class="max-w-md w-full space-y-8 bg-white p-8 rounded-3xl shadow-2xl border border-slate-100">
        
        <!-- Header Icon & Title -->
        <div class="text-center space-y-3">
            <div class="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600 text-3xl mx-auto shadow-inner">
                <i class="fa-solid fa-users-gear"></i>
            </div>
            <h2 class="text-3xl font-extrabold text-slate-900 tracking-tight">Login Panitia TPS</h2>
            <p class="text-xs text-slate-500 max-w-sm mx-auto">
                Masuk ke panel untuk menginput rekapitulasi suara dari TPS Anda ke sistem pusat.
            </p>
        </div>

        <!-- Login Form -->
        <form action="<?= base_url('tps/login') ?>" method="POST" class="mt-8 space-y-6">
            <div>
                <label for="username" class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                    Username Akun TPS
                </label>
                <div class="relative rounded-xl shadow-sm">
                    <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-slate-400">
                        <i class="fa-solid fa-user text-lg"></i>
                    </div>
                    <input type="text" id="username" name="username" required placeholder="Contoh: tps1" class="block w-full pl-11 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-xl font-mono text-base font-bold text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all">
                </div>
            </div>

            <div>
                <label for="password" class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                    Password
                </label>
                <div class="relative rounded-xl shadow-sm">
                    <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-slate-400">
                        <i class="fa-solid fa-lock text-lg"></i>
                    </div>
                    <input type="password" id="password" name="password" required placeholder="Masukkan password..." class="block w-full pl-11 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-xl font-mono text-base font-bold text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all">
                </div>
            </div>

            <button type="submit" class="w-full flex justify-center items-center gap-2 py-4 px-4 border border-transparent text-base font-bold rounded-xl text-white bg-blue-600 hover:bg-blue-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 shadow-lg shadow-blue-600/30 transition-all">
                <i class="fa-solid fa-right-to-bracket"></i> Masuk ke Panel TPS
            </button>
        </form>

        <div class="pt-6 border-t border-slate-100 text-center">
            <p class="text-xs text-slate-400 mb-2">
                Hanya untuk panitia TPS resmi. 
            </p>
            <p class="text-xs font-mono text-slate-500">
                Demo Default:<br/>
                Username: tps1, Password: tps12026
            </p>
        </div>

    </div>
</div>
