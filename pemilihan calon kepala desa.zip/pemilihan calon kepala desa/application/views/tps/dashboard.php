<div class="bg-blue-900 text-white border-b border-blue-800 py-3 px-4 sm:px-6 lg:px-8">
    <div class="max-w-7xl mx-auto flex flex-wrap justify-between items-center gap-4">
        <div class="flex items-center gap-3">
            <span class="bg-blue-500/20 text-blue-300 border border-blue-500/30 px-3 py-1 rounded-lg text-xs font-bold uppercase tracking-wider">
                <i class="fa-solid fa-users-viewfinder mr-1"></i> PANEL TPS <?= $tps_number ?>
            </span>
            <span class="text-sm font-semibold text-slate-300 hidden sm:inline">
                <i class="fa-solid fa-location-dot mr-1"></i> <?= htmlspecialchars($location) ?>
            </span>
        </div>

        <div class="flex flex-wrap items-center gap-3">
            <div class="text-sm">
                <span class="text-slate-400">Petugas:</span> <strong class="text-white"><?= htmlspecialchars($officer_name) ?></strong>
            </div>
            <a href="<?= base_url('tps/logout') ?>" class="px-3 py-1.5 rounded-lg text-xs font-bold bg-rose-900/60 hover:bg-rose-800 text-rose-200 border border-rose-800/50 transition-colors">
                <i class="fa-solid fa-right-from-bracket"></i> Keluar
            </a>
        </div>
    </div>
</div>

<div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
    
    <div class="bg-white p-6 sm:p-8 rounded-3xl shadow-xl border-4 border-blue-900 relative overflow-hidden">
        <div class="absolute top-0 inset-x-0 bg-blue-900 text-white py-2 text-xs font-extrabold tracking-widest uppercase text-center">
            INPUT DATA REKAPITULASI SUARA TPS <?= $tps_number ?>
        </div>

        <div class="mt-6 flex flex-col md:flex-row gap-6 md:gap-8 items-center md:items-start justify-between text-center md:text-left">
            <div class="flex-1 flex flex-col items-center md:items-start">
                <h2 class="text-2xl font-black text-slate-900 uppercase">Input Suara Calon</h2>
                <p class="text-sm text-slate-600 mt-2 max-w-2xl">
                    Masukkan total perolehan suara sah masing-masing calon Kepala Desa dari hasil perhitungan di TPS Anda. Data yang diinput di sini akan langsung terhubung ke <strong class="text-emerald-600">Live Quick Count Pusat</strong>.
                </p>

                <?php if (!empty($ballots)): ?>
                    <div class="mt-4 inline-flex items-center gap-2 bg-amber-50 text-amber-700 px-3 py-2 border border-amber-200 rounded-lg text-xs font-bold text-left">
                        <i class="fa-solid fa-triangle-exclamation"></i>
                        Anda sudah pernah menginput data. Menginput data baru akan MENAMBAHKAN total suara ke data sebelumnya (akumulatif).
                    </div>
                <?php endif; ?>
            </div>

            <!-- DPT Stats for this TPS -->
            <div class="bg-slate-50 p-4 rounded-2xl border border-slate-200 flex-shrink-0 w-full md:w-64">
                <h3 class="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3 text-center border-b border-slate-200 pb-2">Data Pemilih (DPT) TPS <?= $tps_number ?></h3>
                <div class="space-y-2">
                    <div class="flex justify-between items-center text-sm">
                        <span class="text-slate-600 font-medium">Total DPT (Sesuai Input)</span>
                        <span class="font-black text-slate-900"><?= $total_suara_input ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>

<!-- Form Input 1 Suara -->
    <div class="bg-white p-6 sm:p-8 rounded-3xl shadow-xl border border-blue-100">
        <h3 class="text-xl font-black text-slate-900 mb-6 text-center">Form Input Surat Suara</h3>
        
        <form action="<?= base_url('tps/input_suara') ?>" method="POST" enctype="multipart/form-data" class="space-y-8" id="formInputSuara">
            
            <!-- Input Suara Calon -->
            <div>
                <label class="block text-sm font-bold text-slate-700 mb-4 text-center">1. Masukkan Jumlah Suara Masing-masing Calon <span class="text-rose-500">*</span></label>
                <div class="flex flex-wrap justify-center gap-3 sm:gap-4">
                    <?php foreach ($candidates as $cand): ?>
                        <div class="w-[47%] sm:w-[30%] md:w-[23%] p-3 sm:p-4 bg-white rounded-2xl border-2 border-slate-200 hover:border-blue-300 transition-all text-center">
                            <div class="w-12 h-16 sm:w-16 sm:h-20 mx-auto rounded-xl overflow-hidden bg-white border border-slate-100 mb-2">
                                <img src="<?= base_url('uploads/candidates/' . $cand['photo']) ?>" class="w-full h-full object-cover">
                            </div>
                            <span class="bg-slate-800 text-white text-[10px] font-bold px-2 py-0.5 rounded block w-max mx-auto mb-1">0<?= $cand['candidate_number'] ?></span>
                            <h4 class="font-bold text-slate-900 text-[10px] sm:text-xs h-8 sm:h-8 line-clamp-2 leading-tight"><?= htmlspecialchars($cand['full_name']) ?></h4>
                            
                            <div class="mt-3 sm:mt-4 bg-slate-50 p-2 sm:p-3 rounded-xl border border-slate-200">
                                <label class="text-[9px] sm:text-xs text-slate-500 font-bold block mb-1 sm:mb-2 uppercase tracking-wider">Ketik Suara</label>
                                <input type="number" name="votes[<?= $cand['id'] ?>]" min="0" value="0" class="w-full text-center font-black text-2xl sm:text-3xl text-slate-800 bg-white border-2 border-slate-300 rounded-lg py-2 sm:py-3 shadow-inner hover:border-blue-400 focus:outline-none focus:border-blue-600 focus:ring-4 focus:ring-blue-600/20 transition-all cursor-text" required>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <hr class="border-slate-100">

            <!-- Upload Foto -->
            <div class="max-w-md mx-auto">
                <label class="block text-sm font-bold text-slate-700 mb-2 text-center">2. Unggah Bukti Hasil Suara (Plano/C1) <span class="text-rose-500">*</span></label>
                <p class="text-xs text-slate-500 text-center mb-4">Pastikan foto jelas dan memperlihatkan rekapitulasi perolehan suara.</p>
                <input type="file" name="evidence_photo" accept="image/jpeg,image/png,image/gif" class="block w-full text-sm text-slate-500 file:mr-4 file:py-2.5 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 border border-slate-200 rounded-full cursor-pointer" required>
            </div>

            <div class="text-center pt-4">
                <button type="submit" class="bg-blue-600 hover:bg-blue-500 text-white font-extrabold px-10 py-4 rounded-xl shadow-lg shadow-blue-600/30 transition-all gap-2 text-lg inline-flex items-center">
                    <i class="fa-solid fa-paper-plane"></i> Kirim Data Suara
                </button>
            </div>
        </form>
    </div>

    <!-- Riwayat Suara -->
    <div class="bg-white rounded-3xl shadow-sm border border-slate-200 p-6 sm:p-8 mt-8">
        <h3 class="text-lg font-extrabold text-slate-900 mb-6">Riwayat Suara Masuk TPS <?= $tps_number ?></h3>
        
        <?php if (!empty($ballots)): ?>
            <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                <?php foreach ($ballots as $index => $ballot): ?>
                    <div class="bg-slate-50 rounded-xl border border-slate-200 overflow-hidden relative group">
                        <a href="<?= base_url('uploads/evidence/' . $ballot['evidence_photo']) ?>" target="_blank" class="block h-32 bg-slate-200 overflow-hidden">
                            <img src="<?= base_url('uploads/evidence/' . $ballot['evidence_photo']) ?>" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300">
                        </a>
                        <div class="p-3">
                            <span class="text-[10px] text-slate-400 block mb-1"><?= date('H:i', strtotime($ballot['created_at'])) ?></span>
                            <div class="font-bold text-slate-900 text-xs line-clamp-1">0<?= $ballot['candidate_number'] ?> - <?= htmlspecialchars($ballot['full_name']) ?></div>
                            <div class="text-[11px] font-bold text-blue-600 mt-1"><?= $ballot['vote_count'] ?> Suara</div>
                        </div>
                        <a href="<?= base_url('tps/delete_ballot/' . $ballot['id']) ?>" onclick="return confirm('Yakin ingin menghapus suara ini?')" class="absolute top-2 right-2 w-7 h-7 bg-white/90 hover:bg-rose-500 hover:text-white text-rose-500 rounded-full flex items-center justify-center shadow-sm transition-colors opacity-0 group-hover:opacity-100">
                            <i class="fa-solid fa-trash-can text-xs"></i>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="text-center py-10 bg-slate-50 rounded-2xl border border-slate-200 border-dashed">
                <i class="fa-solid fa-box-open text-4xl text-slate-300 mb-3 block"></i>
                <p class="text-slate-500 font-medium">Belum ada suara yang diinput.</p>
            </div>
        <?php endif; ?>
    </div>
</div>
