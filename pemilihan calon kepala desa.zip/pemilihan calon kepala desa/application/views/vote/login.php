<div class="min-h-[80vh] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
    <div class="max-w-md w-full space-y-8 bg-white p-8 rounded-3xl shadow-2xl border border-slate-100">
        
        <!-- Header Icon & Title -->
        <div class="text-center space-y-3">
            <div class="w-16 h-16 bg-emerald-50 rounded-2xl flex items-center justify-center text-emerald-600 text-3xl mx-auto shadow-inner">
                <i class="fa-solid fa-fingerprint"></i>
            </div>
            <h2 class="text-3xl font-extrabold text-slate-900 tracking-tight">Otentikasi Pemilih</h2>
            <p class="text-xs text-slate-500 max-w-sm mx-auto">
                Masukkan NIK (Nomor Induk Kependudukan) atau Kode Akses Pemilih yang terdaftar pada DPT Desa Samudrajaya.
            </p>
        </div>

        <!-- Login Form -->
        <form action="<?= base_url('vote') ?>" method="POST" class="mt-8 space-y-6">
            <div>
                <label for="nik" class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                    NIK / Kode Akses Pemilih
                </label>
                <div class="relative rounded-xl shadow-sm">
                    <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-slate-400">
                        <i class="fa-solid fa-id-card text-lg"></i>
                    </div>
                    <input type="text" id="nik" name="nik" required placeholder="Masukkan NIK 16 digit..." class="block w-full pl-11 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-xl font-mono text-base font-bold text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition-all">
                </div>
            </div>

            <button type="submit" class="w-full flex justify-center items-center gap-2 py-4 px-4 border border-transparent text-base font-bold rounded-xl text-white bg-emerald-600 hover:bg-emerald-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500 shadow-lg shadow-emerald-600/30 transition-all">
                <i class="fa-solid fa-right-to-bracket"></i> Masuk Ke Bilik Suara
            </button>
        </form>

        <!-- Sample Voter NIK Helper for Demo & Testing -->
        <div class="pt-6 border-t border-slate-100">
            <p class="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 text-center">
                Daftar NIK Sampel (Klik untuk mencoba)
            </p>
            <div class="flex flex-wrap justify-center gap-1.5 text-xs font-mono">
                <button type="button" onclick="document.getElementById('nik').value='3171010101900001'" class="bg-slate-100 hover:bg-emerald-100 hover:text-emerald-800 text-slate-700 px-2.5 py-1 rounded-md border border-slate-200 transition-colors">
                    3171010101900001 (Budi)
                </button>
                <button type="button" onclick="document.getElementById('nik').value='3171010101900002'" class="bg-slate-100 hover:bg-emerald-100 hover:text-emerald-800 text-slate-700 px-2.5 py-1 rounded-md border border-slate-200 transition-colors">
                    3171010101900002 (Dewi)
                </button>
                <button type="button" onclick="document.getElementById('nik').value='3171010101900003'" class="bg-slate-100 hover:bg-emerald-100 hover:text-emerald-800 text-slate-700 px-2.5 py-1 rounded-md border border-slate-200 transition-colors">
                    3171010101900003 (Eko)
                </button>
            </div>
        </div>

    </div>
</div>
