<!-- Voter Identity Bar -->
<div class="bg-gradient-to-r from-slate-900 to-slate-800 text-white py-4 px-4 sm:px-6 lg:px-8 border-b border-slate-700 shadow-md">
    <div class="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-3">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-full bg-emerald-500 text-slate-900 font-extrabold flex items-center justify-center text-lg">
                <i class="fa-solid fa-user-check"></i>
            </div>
            <div>
                <span class="text-xs text-emerald-400 uppercase font-semibold">Identitas Pemilih Aktif</span>
                <h4 class="text-base font-extrabold text-white leading-tight">
                    <?= htmlspecialchars($voter['name']) ?> <span class="text-slate-400 font-normal text-xs">(NIK: <?= htmlspecialchars($voter['nik']) ?>)</span>
                </h4>
            </div>
        </div>

        <div class="flex items-center gap-4">
            <span class="bg-slate-800 border border-slate-700 text-slate-300 text-xs px-3 py-1.5 rounded-lg font-mono">
                <i class="fa-solid fa-location-dot text-emerald-400 mr-1"></i> <?= htmlspecialchars($voter['rt_rw']) ?>
            </span>
            <a href="<?= base_url('vote/logout') ?>" class="text-xs font-semibold text-rose-400 hover:text-rose-300 transition-colors">
                <i class="fa-solid fa-power-off"></i> Batal / Keluar
            </a>
        </div>
    </div>
</div>

<!-- Ballot Paper Header -->
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-10">
    <div class="bg-white p-6 sm:p-8 rounded-3xl shadow-xl border-4 border-slate-900 text-center relative overflow-hidden">
        <div class="absolute top-0 inset-x-0 bg-slate-900 text-white py-2 text-xs font-extrabold tracking-widest uppercase">
            SURAT SUARA ELEKTRONIK RESMI PILKADES MAKMAR SEJAHTERA
        </div>

        <div class="mt-4 space-y-2">
            <div class="inline-block p-3 bg-emerald-50 text-emerald-700 rounded-full text-2xl mb-1">
                <i class="fa-solid fa-box-archive"></i>
            </div>
            <h2 class="text-2xl sm:text-4xl font-black text-slate-900 uppercase tracking-tight">SURAT SUARA DIGITAL</h2>
            <p class="text-sm text-slate-600 max-w-xl mx-auto">
                Silakan sentuh atau klik tombol <strong class="text-emerald-600">"Pilih / Coblos Calon Ini"</strong> di bawah foto calon pilihan Anda. Pilihan bersifat rahasia dan tidak dapat diubah setelah dikonfirmasi.
            </p>
        </div>
    </div>
</div>

<!-- Ballot Grid -->
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8 mb-20">
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <?php foreach ($candidates as $cand): ?>
            <div class="bg-white rounded-3xl shadow-xl border-2 border-slate-200 overflow-hidden flex flex-col hover:border-emerald-500 transition-all duration-300">
                
                <!-- Candidate Header Banner -->
                <div class="bg-slate-900 text-white py-4 px-6 text-center border-b-4 border-emerald-500 flex justify-between items-center">
                    <span class="text-xs font-extrabold uppercase tracking-widest text-emerald-400">CALON KEPALA DESA</span>
                    <span class="text-2xl font-black text-white bg-slate-800 w-10 h-10 rounded-full flex items-center justify-center border border-slate-700">
                        0<?= $cand['candidate_number'] ?>
                    </span>
                </div>

                <!-- Photo Frame -->
                <div class="p-6 bg-slate-50 text-center flex-grow flex flex-col justify-between">
                    <div>
                        <div class="w-56 h-64 mx-auto overflow-hidden rounded-2xl border-4 border-white shadow-xl bg-white flex items-center justify-center mb-4">
                            <img src="<?= base_url('uploads/candidates/' . $cand['photo']) ?>" alt="<?= htmlspecialchars($cand['full_name']) ?>" class="w-full h-full object-cover" onerror="this.src='<?= base_url('uploads/candidates/default_candidate.svg') ?>'">
                        </div>

                        <h3 class="text-xl font-extrabold text-slate-900">
                            <?= htmlspecialchars($cand['full_name']) ?>
                        </h3>


                    </div>

                    <!-- Vote Button -->
                    <div class="mt-6 pt-4 border-t border-slate-200">
                        <button type="button" onclick="confirmVote(<?= $cand['id'] ?>, <?= $cand['candidate_number'] ?>, '<?= addslashes(htmlspecialchars($cand['full_name'])) ?>')" class="w-full py-4 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-base shadow-lg shadow-emerald-600/30 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2">
                            <i class="fa-solid fa-check-double text-lg"></i> PILIH CALON NO. 0<?= $cand['candidate_number'] ?>
                        </button>
                    </div>
                </div>

            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Hidden Form for Submit -->
<form id="vote-form" action="<?= base_url('vote/submit') ?>" method="POST" class="hidden">
    <input type="hidden" id="selected-candidate-id" name="candidate_id" value="">
</form>

<!-- SweetAlert Confirmation Handler -->
<script>
    function confirmVote(id, number, name) {
        Swal.fire({
            title: 'Konfirmasi Pilihan Suara',
            html: `Apakah Anda yakin ingin memilih:<br><br><strong class="text-2xl text-emerald-600">No. 0${number} - ${name}</strong><br><br><span class="text-xs text-slate-500">Pilihan suara Anda akan langsung terhitung secara permanen dan tidak dapat diubah setelahnya.</span>`,
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#059669',
            cancelButtonColor: '#64748b',
            confirmButtonText: '<i class="fa-solid fa-check mr-1"></i> Ya, Mantap Pilih!',
            cancelButtonText: 'Batal / Pikir-pikir Dulu',
            customClass: {
                popup: 'rounded-3xl',
                confirmButton: 'rounded-xl text-base px-6 py-3 font-bold',
                cancelButton: 'rounded-xl text-base px-6 py-3 font-semibold'
            }
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('selected-candidate-id').value = id;
                document.getElementById('vote-form').submit();
            }
        });
    }
</script>
