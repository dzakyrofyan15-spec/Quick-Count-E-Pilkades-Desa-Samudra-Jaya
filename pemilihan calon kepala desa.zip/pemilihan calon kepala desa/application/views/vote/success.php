<div class="min-h-[80vh] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
    <div class="max-w-lg w-full bg-white p-8 rounded-3xl shadow-2xl border border-slate-100 text-center relative overflow-hidden">
        
        <!-- Top Success Badge -->
        <div class="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center text-4xl mx-auto shadow-inner mb-4">
            <i class="fa-solid fa-circle-check"></i>
        </div>

        <h2 class="text-3xl font-extrabold text-slate-900 tracking-tight">Suara Anda Berhasil Disalurkan!</h2>
        <p class="text-sm text-slate-600 mt-2">
            Terima kasih telah berpartisipasi aktif dalam Pesta Demokrasi Pemilihan Kepala Desa Samudrajaya.
        </p>

        <!-- Official Electronic Vote Receipt Card -->
        <div class="mt-6 bg-slate-50 p-6 rounded-2xl border border-slate-200 text-left relative space-y-3 font-mono text-xs">
            <div class="flex justify-between items-center border-b border-slate-200 pb-3">
                <span class="font-bold text-slate-900 uppercase">BUKTI VOTING ELEKTRONIK</span>
                <span class="bg-emerald-100 text-emerald-800 font-extrabold px-2.5 py-0.5 rounded text-[10px]">VERIFIED</span>
            </div>

            <div class="flex justify-between">
                <span class="text-slate-500">Nama Pemilih:</span>
                <span class="font-bold text-slate-800"><?= htmlspecialchars($voter_name) ?></span>
            </div>

            <div class="flex justify-between">
                <span class="text-slate-500">NIK Pemilih:</span>
                <span class="font-bold text-slate-800"><?= htmlspecialchars($voter_nik) ?></span>
            </div>

            <div class="flex justify-between">
                <span class="text-slate-500">Waktu Memilih:</span>
                <span class="font-bold text-slate-800"><?= date('d-m-Y H:i:s') ?> WIB</span>
            </div>

            <div class="flex justify-between border-t border-slate-200 pt-3">
                <span class="text-slate-500">Status Suara:</span>
                <span class="font-extrabold text-emerald-600">TERHITUNG OTOMATIS</span>
            </div>
        </div>

        <!-- Action Buttons -->
        <div class="mt-8 space-y-3">
            <a href="<?= base_url() ?>" class="w-full inline-flex justify-center items-center gap-2 py-4 px-4 border border-transparent text-base font-bold rounded-xl text-white bg-slate-900 hover:bg-slate-800 shadow-lg transition-all">
                <i class="fa-solid fa-chart-pie text-emerald-400"></i> Pantau Live Quick Count
            </a>

            <a href="<?= base_url('vote/logout') ?>" class="w-full inline-flex justify-center items-center gap-2 py-3 px-4 text-sm font-semibold rounded-xl text-slate-600 hover:bg-slate-100 transition-colors">
                <i class="fa-solid fa-right-from-bracket"></i> Keluar Dari Sesi Pemilihan
            </a>
        </div>

    </div>
</div>
