<?php
// Generator SVG Avatar Calon Kepala Desa (Tanpa ketergantungan GD extension)
function createSvgAvatar($filename, $number, $name, $bgColor, $accentColor, $avatarColor) {
    $initials = '';
    $words = explode(' ', $name);
    foreach ($words as $w) {
        if (!empty($w) && strlen($w) > 2 && $w[0] !== '(') {
            $initials .= strtoupper($w[0]);
        }
    }
    $initials = substr($initials, 0, 2);
    if (empty($initials)) $initials = 'C' . $number;

    $svg = '<?xml version="1.0" encoding="UTF-8"?>
<svg width="400" height="500" viewBox="0 0 400 500" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="400" height="500" rx="16" fill="' . $bgColor . '"/>
    
    <!-- Top Badge Header -->
    <rect width="400" height="100" fill="' . $accentColor . '"/>
    <circle cx="200" cy="50" r="30" fill="#FFFFFF" fill-opacity="0.2"/>
    <text x="200" y="58" font-family="system-ui, -apple-system, sans-serif" font-size="28" font-weight="bold" fill="#FFFFFF" text-anchor="middle">CALON ' . ($number > 0 ? '0' . $number : '') . '</text>

    <!-- Avatar Circle -->
    <circle cx="200" cy="240" r="110" fill="#FFFFFF"/>
    <circle cx="200" cy="240" r="100" fill="' . $avatarColor . '"/>
    
    <!-- Head & Body Silhouette -->
    <circle cx="200" cy="200" r="42" fill="#FFFFFF"/>
    <path d="M 125 295 C 125 240, 275 240, 275 295 Z" fill="#FFFFFF"/>
    
    <!-- Initials Overlay -->
    <rect x="150" y="300" width="100" height="40" rx="20" fill="' . $accentColor . '"/>
    <text x="200" y="326" font-family="system-ui, -apple-system, sans-serif" font-size="20" font-weight="800" fill="#FFFFFF" text-anchor="middle">' . $initials . '</text>

    <!-- Bottom Name Card -->
    <rect y="400" width="400" height="100" fill="#0F172A"/>
    <text x="200" y="445" font-family="system-ui, -apple-system, sans-serif" font-size="20" font-weight="bold" fill="#FFFFFF" text-anchor="middle">' . htmlspecialchars($name) . '</text>
    <text x="200" y="475" font-family="system-ui, -apple-system, sans-serif" font-size="14" fill="#94A3B8" text-anchor="middle">Calon Kepala Desa</text>
</svg>';

    $savePath = __DIR__ . '/../../uploads/candidates/' . $filename;
    file_put_contents($savePath, $svg);
}

if (!is_dir(__DIR__ . '/../../uploads/candidates')) {
    mkdir(__DIR__ . '/../../uploads/candidates', 0777, true);
}

createSvgAvatar('calon_1.svg', 1, 'H. Ahmad Subarkah', '#E0F2FE', '#0284C7', '#0369A1');
createSvgAvatar('calon_2.svg', 2, 'Drs. Bambang Wijaya', '#FEF3C7', '#D97706', '#B45309');
createSvgAvatar('calon_3.svg', 3, 'Siti Rahmawati', '#FCE7F3', '#DB2777', '#BE185D');
createSvgAvatar('default_candidate.svg', 0, 'Foto Calon', '#F1F5F9', '#475569', '#334155');

echo "Generated SVG avatar files successfully!\n";
