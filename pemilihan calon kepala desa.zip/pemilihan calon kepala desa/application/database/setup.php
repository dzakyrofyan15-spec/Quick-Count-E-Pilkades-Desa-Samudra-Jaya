<?php
// Script inisialisasi Database SQLite Pilkades
$dbPath = __DIR__ . '/db_pilkades.sqlite';

try {
    $pdo = new PDO('sqlite:' . $dbPath);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec("PRAGMA journal_mode=WAL");

    // Create candidates table
    $pdo->exec("CREATE TABLE IF NOT EXISTS candidates (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        candidate_number INTEGER NOT NULL UNIQUE,
        full_name VARCHAR(100) NOT NULL,
        photo VARCHAR(255) DEFAULT 'default_candidate.png',
        vision TEXT,
        mission TEXT,
        slogan VARCHAR(255),
        vote_count INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );");

    // Create voters table (DPT - Daftar Pemilih Tetap)
    // is_voted dipertahankan untuk tracking partisipasi
    $pdo->exec("CREATE TABLE IF NOT EXISTS voters (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nik VARCHAR(30) NOT NULL UNIQUE,
        name VARCHAR(100) NOT NULL,
        rt_rw VARCHAR(20) DEFAULT 'RT 01 / RW 01',
        tps_number INTEGER DEFAULT 1,
        is_voted INTEGER DEFAULT 0,
        voted_at DATETIME NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );");

    // Create tps_ballots table (Input per lembar suara oleh TPS)
    $pdo->exec("CREATE TABLE IF NOT EXISTS tps_ballots (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        candidate_id INTEGER NOT NULL,
        tps_number INTEGER NOT NULL,
        evidence_photo VARCHAR(255) NOT NULL,
        inputted_by INTEGER NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );");

    // Create admins table (Super admin / panitia pusat)
    $pdo->exec("CREATE TABLE IF NOT EXISTS admins (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username VARCHAR(50) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        name VARCHAR(100) NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );");

    // Create tps_officers table (Panitia di setiap TPS)
    $pdo->exec("CREATE TABLE IF NOT EXISTS tps_officers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tps_number INTEGER NOT NULL UNIQUE,
        username VARCHAR(50) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        name VARCHAR(100) NOT NULL,
        location VARCHAR(150) DEFAULT '',
        is_active INTEGER DEFAULT 1,
        evidence_photo VARCHAR(255) NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );");

    // Create settings table
    $pdo->exec("CREATE TABLE IF NOT EXISTS settings (
        setting_key VARCHAR(50) PRIMARY KEY,
        setting_value TEXT
    );");

    // Seed Admin default if empty
    $stmt = $pdo->query("SELECT COUNT(*) FROM admins");
    if ($stmt->fetchColumn() == 0) {
        $defaultPassword = password_hash('admin123', PASSWORD_BCRYPT);
        $stmtAdmin = $pdo->prepare("INSERT INTO admins (username, password, name) VALUES (?, ?, ?)");
        $stmtAdmin->execute(['admin', $defaultPassword, 'Panitia Pemilihan Desa (Admin)']);
    }

    // Seed TPS Officers (TPS 1 - 12) if empty
    $stmt = $pdo->query("SELECT COUNT(*) FROM tps_officers");
    if ($stmt->fetchColumn() == 0) {
        $stmtTps = $pdo->prepare("INSERT INTO tps_officers (tps_number, username, password, name, location) VALUES (?, ?, ?, ?, ?)");
        $locations = [
            1 => 'Balai Dusun 1 - RT 01 s/d RT 03',
            2 => 'SDN 1 Desa - RT 04 s/d RT 06',
            3 => 'Kantor RW 01 - RT 07 s/d RT 09',
            4 => 'Masjid Al-Ikhlas - RT 10 s/d RT 12',
            5 => 'Balai Dusun 2 - RT 13 s/d RT 15',
            6 => 'Gedung Serbaguna - RT 16 s/d RT 18',
            7 => 'PAUD Dahlia - RT 19 s/d RT 21',
            8 => 'Balai RW 03 - RT 22 s/d RT 24',
            9 => 'Lapangan Bola - RT 25 s/d RT 27',
            10 => 'Posyandu Mawar - RT 28 s/d RT 30',
            11 => 'Balai Dusun 3 - RT 31 s/d RT 33',
            12 => 'Aula PKK - RT 34 s/d RT 36',
        ];
        for ($i = 1; $i <= 12; $i++) {
            $tpsPass = password_hash('tps' . $i . '2026', PASSWORD_BCRYPT);
            $stmtTps->execute([
                $i,
                'tps' . $i,
                $tpsPass,
                'Panitia TPS ' . $i,
                $locations[$i]
            ]);
        }
    }

    // Seed Village settings if empty
    $stmt = $pdo->query("SELECT COUNT(*) FROM settings");
    if ($stmt->fetchColumn() == 0) {
        $stmtSet = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?)");
        $stmtSet->execute(['village_name', 'Desa Makmur Sejahtera']);
        $stmtSet->execute(['election_year', '2026']);
        $stmtSet->execute(['tps_total', '12']);
    }

    // Seed sample candidates if empty
    $stmt = $pdo->query("SELECT COUNT(*) FROM candidates");
    if ($stmt->fetchColumn() == 0) {
        $stmtCand = $pdo->prepare("INSERT INTO candidates (candidate_number, full_name, photo, vision, mission, slogan, vote_count) VALUES (?, ?, ?, ?, ?, ?, ?)");
        
        $stmtCand->execute([
            1,
            'H. Ahmad Subarkah, S.IP.',
            'calon_1.svg',
            'Mewujudkan Desa Makmur Sejahtera yang Mandiri, Transparan, Berkelanjutan, dan Berbasis Ekonomi Kreatif.',
            "1. Meningkatkan kualitas pelayanan publik desa secara digital.\n2. Mengoptimalkan BUMDes untuk pemberdayaan ekonomi warga.\n3. Pembangunan infrastruktur jalan & irigasi desa yang adil.",
            'Maju Bersama, Sejahtera Untuk Semua',
            0
        ]);

        $stmtCand->execute([
            2,
            'Drs. Bambang Wijaya, M.Si.',
            'calon_2.svg',
            'Membangun Desa Makmur yang Religius, Aman, Sejahtera, dan Berbudaya.',
            "1. Program beasiswa dan bantuan pendidikan bagi anak berprestasi.\n2. Peningkatan sarana kesehatan dan posyandu desa.\n3. Penguatan keamanan desa dan gotong royong warga.",
            'Kerja Nyata untuk Kemajuan Desa',
            0
        ]);

        $stmtCand->execute([
            3,
            'Siti Rahmawati, S.Pd.',
            'calon_3.svg',
            'Pemberdayaan Perempuan, Pemuda, dan Usaha Mikro dalam Menciptakan Desa Inovatif.',
            "1. Pelatihan digitalisasi UMKM dan akses permodalan usaha desa.\n2. Pendirian pusat kegiatan pemuda dan olahraga desa.\n3. Trasparansi anggaran desa berbasis portal informasi publik.",
            'Inovatif, Jujur, dan Mengayomi',
            0
        ]);
    }

    // Seed sample voters/DPT if empty
    $stmt = $pdo->query("SELECT COUNT(*) FROM voters");
    if ($stmt->fetchColumn() == 0) {
        $stmtVoter = $pdo->prepare("INSERT INTO voters (nik, name, rt_rw, tps_number, is_voted) VALUES (?, ?, ?, ?, 0)");
        $sampleVoters = [
            ['3171010101900001', 'Budi Santoso', 'RT 01 / RW 01', 1],
            ['3171010101900002', 'Dewi Lestari', 'RT 01 / RW 01', 2],
            ['3171010101900003', 'Eko Prasetyo', 'RT 02 / RW 01', 3],
            ['3171010101900004', 'Fitri Handayani', 'RT 02 / RW 01', 4],
            ['3171010101900005', 'Hendra Gunawan', 'RT 03 / RW 02', 5],
            ['3171010101900006', 'Indah Permata', 'RT 03 / RW 02', 6],
            ['3171010101900007', 'Joko Susilo', 'RT 04 / RW 02', 7],
            ['3171010101900008', 'Karisma Putri', 'RT 04 / RW 02', 8],
            ['3171010101900009', 'Lukman Hakim', 'RT 05 / RW 03', 9],
            ['3171010101900010', 'Maya Sari', 'RT 05 / RW 03', 10],
        ];
        foreach ($sampleVoters as $v) {
            $stmtVoter->execute($v);
        }
    }

    echo "Database SQLite successfully initialized & seeded!";
} catch (PDOException $e) {
    echo "Database setup error: " . $e->getMessage();
}
